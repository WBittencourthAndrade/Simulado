import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { questions } from "@/db/schema";
import { batchConfig } from "@/lib/generator";
import { errorResponse, HttpError, readJson } from "@/lib/http";
import { loadQuiz, refreshCounters, toPublicQuiz } from "@/lib/quiz";
import { isLetter } from "@/lib/types";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** Modo simulado (ou encerramento antecipado): grava as respostas e libera TODOS os comentários. */
export async function POST(req: Request, ctx: Ctx) {
  try {
    await ensureSchema();
    const { id } = await ctx.params;
    const body = await readJson(req);
    const answers = body.answers && typeof body.answers === "object" ? (body.answers as Record<string, unknown>) : {};
    const data = await loadQuiz(id);
    if (!data) throw new HttpError(404, "Simulado não encontrado.");
    if (data.quiz.status === "generating") throw new HttpError(409, "As questões ainda estão sendo geradas.");

    if (data.quiz.status !== "finished") {
      const now = new Date();
      for (const q of data.qs) {
        const a = answers[q.id];
        if (q.userAnswer || !isLetter(a)) continue;
        await db
          .update(questions)
          .set({ userAnswer: a, isCorrect: a === q.correct, answeredAt: now })
          .where(and(eq(questions.id, q.id), isNull(questions.userAnswer)));
      }
      await refreshCounters(id, true);
    }
    const fresh = await loadQuiz(id);
    if (!fresh) throw new HttpError(404, "Simulado não encontrado.");
    return Response.json(toPublicQuiz(fresh.quiz, fresh.qs, batchConfig()));
  } catch (err) {
    return errorResponse(err);
  }
}
