import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { quizzes } from "@/db/schema";
import { batchConfig } from "@/lib/generator";
import { errorResponse, HttpError, UUID_RE } from "@/lib/http";
import { loadQuiz, toPublicQuiz } from "@/lib/quiz";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  try {
    await ensureSchema();
    const { id } = await ctx.params;
    const data = await loadQuiz(id);
    if (!data) throw new HttpError(404, "Simulado não encontrado.");
    return Response.json(toPublicQuiz(data.quiz, data.qs, batchConfig()));
  } catch (err) {
    return errorResponse(err);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    await ensureSchema();
    const { id } = await ctx.params;
    if (!UUID_RE.test(id)) throw new HttpError(404, "Simulado não encontrado.");
    await db.delete(quizzes).where(eq(quizzes.id, id));
    return Response.json({ ok: true });
  } catch (err) {
    return errorResponse(err);
  }
}
