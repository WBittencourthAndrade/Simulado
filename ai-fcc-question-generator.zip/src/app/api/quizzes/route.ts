import { desc } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { quizzes } from "@/db/schema";
import { getProvider } from "@/lib/ai";
import { errorResponse, HttpError, readJson, UUID_RE } from "@/lib/http";
import { buildPlan } from "@/lib/quiz";
import { clip } from "@/lib/text";

export const dynamic = "force-dynamic";

const MAX_QUESTIONS = 50;

export async function POST(req: Request) {
  try {
    await ensureSchema();
    const body = await readJson(req);
    const subject = typeof body.subject === "string" ? body.subject.trim() : "";
    if (subject.length < 2 || subject.length > 120) throw new HttpError(400, "Informe a matéria (entre 2 e 120 caracteres).");
    const cargo = typeof body.cargo === "string" && body.cargo.trim() ? clip(body.cargo.trim(), 120) : null;
    const rawTopics = Array.isArray(body.topics) ? body.topics : [];
    const topics = Array.from(
      new Set(rawTopics.filter((t): t is string => typeof t === "string").map((t) => clip(t.trim(), 140)).filter(Boolean)),
    ).slice(0, 20);
    const finalTopics = topics.length ? topics : [subject];
    const count = Math.round(Number(body.count));
    if (!Number.isFinite(count) || count < 1 || count > MAX_QUESTIONS)
      throw new HttpError(400, `Escolha entre 1 e ${MAX_QUESTIONS} questões.`);
    const mode = body.mode === "simulado" ? "simulado" : "estudo";
    const researchId = typeof body.researchId === "string" && UUID_RE.test(body.researchId) ? body.researchId : null;
    const provider = getProvider();

    const [quiz] = await db
      .insert(quizzes)
      .values({
        subject,
        cargo,
        researchId,
        topics: finalTopics,
        plan: buildPlan(finalTopics, count),
        questionCount: count,
        mode,
        status: "generating",
        engine: provider.premium ? `${provider.label} · ${provider.model}` : "Banco curado + IA gratuita",
      })
      .returning({ id: quizzes.id });
    return Response.json({ id: quiz.id }, { status: 201 });
  } catch (err) {
    return errorResponse(err);
  }
}

export async function GET() {
  try {
    await ensureSchema();
    const rows = await db
      .select({
        id: quizzes.id,
        subject: quizzes.subject,
        cargo: quizzes.cargo,
        mode: quizzes.mode,
        status: quizzes.status,
        questionCount: quizzes.questionCount,
        answeredCount: quizzes.answeredCount,
        correctCount: quizzes.correctCount,
        createdAt: quizzes.createdAt,
      })
      .from(quizzes)
      .orderBy(desc(quizzes.createdAt))
      .limit(60);
    return Response.json(rows);
  } catch (err) {
    return errorResponse(err);
  }
}
