"use client";

import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { FOCUSED_SUGGESTIONS, SUGGESTIONS } from "@/lib/subjects";
import type { EngineStatus, QuizMode, RelevanceLevel, ResearchResult } from "@/lib/types";
import {
  IconArrowRight,
  IconBook,
  IconCheck,
  IconClock,
  IconExternal,
  IconGlobe,
  IconLayers,
  IconMinus,
  IconPlus,
  IconRefresh,
  IconScale,
  IconSearch,
  IconSpark,
  IconTarget,
} from "./icons";

const PRESETS = [5, 10, 15, 20, 30];
const MAX = 50;

const STEPS = [
  "Consultando Estratégia Concursos, TEC Concursos e QConcursos…",
  "Varrendo Gran Cursos, Direção Concursos, AlfaCon e PCI Concursos…",
  "Filtrando conteúdos da Fundação Carlos Chagas (FCC) 100% focados no seu tema…",
  "Mapeando os pontos, artigos e pegadinhas mais cobrados dentro do tema…",
  "Consolidando o recorte estrito de incidência da banca…",
  "Organizando fontes e orientações específicas para o seu tema…",
];

const METHOD_LABEL: Record<string, string> = {
  "web+ia": "Pesquisa ao vivo nos portais + análise por IA",
  ia: "Análise por IA do histórico da banca",
  web: "Pesquisa ao vivo + recorte focado no tema",
  referencia: "Recorte 100% focado no tema",
};

const LEVEL_STYLE: Record<RelevanceLevel, string> = {
  Altíssima: "bg-zinc-100 text-zinc-950",
  Alta: "bg-zinc-300 text-zinc-900",
  Média: "bg-zinc-600 text-zinc-100",
  Baixa: "bg-zinc-800 text-zinc-300",
};

type FocusScope = "laser" | "recortes";

function initials(name: string): string {
  return name
    .replace(/[^A-Za-zÀ-ú ]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 || /^[A-Z]{2,}$/.test(w))
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");
}

export default function Studio() {
  const router = useRouter();
  const [subject, setSubject] = useState("");
  const [cargo, setCargo] = useState("");
  const [focusScope, setFocusScope] = useState<FocusScope>("laser");
  const [chipTab, setChipTab] = useState<"temas" | "materias">("temas");
  const [research, setResearch] = useState<ResearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [custom, setCustom] = useState("");
  const [count, setCount] = useState(10);
  const [mode, setMode] = useState<QuizMode>("estudo");
  const [creating, setCreating] = useState(false);
  const [engine, setEngine] = useState<EngineStatus | null>(null);
  const [showLog, setShowLog] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/api/status", { cache: "no-store" })
      .then((r) => r.json())
      .then((d: EngineStatus) => setEngine(d))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!loading) return;
    const t = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 4200);
    return () => clearInterval(t);
  }, [loading]);

  async function doResearch(force = false) {
    const s = subject.trim();
    if (s.length < 2) {
      setError("Informe o tema, assunto ou matéria que você precisa treinar.");
      return;
    }
    setError(null);
    setStep(0);
    setLoading(true);
    if (!force) setResearch(null);
    setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
    try {
      const res = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject: s, cargo: cargo.trim(), force }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Não foi possível concluir a pesquisa.");
      const r = data as ResearchResult;
      setResearch(r);
      if (focusScope === "laser") {
        setSelected(r.topics.slice(0, Math.min(3, r.topics.length)).map((t) => t.name));
      } else {
        setSelected(r.topics.slice(0, Math.min(5, r.topics.length)).map((t) => t.name));
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  function toggle(name: string) {
    setSelected((cur) => (cur.includes(name) ? cur.filter((n) => n !== name) : [...cur, name]));
  }

  function lockSingleTopic(name: string) {
    setFocusScope("recortes");
    setSelected([name]);
  }

  function addCustom() {
    const v = custom.trim();
    if (!v || !research) return;
    if (!research.topics.some((t) => t.name.toLowerCase() === v.toLowerCase())) {
      setResearch({
        ...research,
        topics: [{ name: v, relevance: 100, level: "Altíssima", why: "Recorte específico definido por você (Foco 100%).", sources: [] }, ...research.topics],
      });
    }
    setSelected((cur) => (cur.includes(v) ? cur : [v, ...cur]));
    setCustom("");
  }

  /** Lista final de tópicos que serão enviados para o gerador, respeitando o modo de foco. */
  const effectiveTopics = useMemo(() => {
    const s = subject.trim();
    if (!research) return s ? [s] : [];
    if (focusScope === "laser") {
      return [research.subject];
    }
    const ordered = research.topics.filter((t) => selected.includes(t.name)).map((t) => t.name);
    return ordered.length ? ordered : [research.subject];
  }, [subject, research, focusScope, selected]);

  /** Distribuição prevista de questões por tópico (espelha `buildPlan` do backend). */
  const distribution = useMemo(() => {
    if (!effectiveTopics.length) return [];
    const counts = new Map<string, number>();
    for (let i = 0; i < count; i++) {
      const t = effectiveTopics[i % effectiveTopics.length];
      counts.set(t, (counts.get(t) ?? 0) + 1);
    }
    return Array.from(counts.entries()).map(([topic, qty]) => ({
      topic,
      qty,
      pct: Math.round((qty / Math.max(1, count)) * 100),
    }));
  }, [effectiveTopics, count]);

  async function createQuiz(directLaser = false) {
    const s = subject.trim();
    if (s.length < 2) {
      setError("Informe o tema, assunto ou matéria que você precisa treinar.");
      return;
    }
    const topics = directLaser ? [s] : effectiveTopics;
    if (!topics.length) {
      setError("Selecione pelo menos um recorte do tema.");
      return;
    }
    setCreating(true);
    setError(null);
    try {
      const res = await fetch("/api/quizzes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject: s, cargo: cargo.trim(), topics, count, mode, researchId: research?.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Falha ao criar o simulado.");
      router.push(`/simulado/${data.id}`);
    } catch (e) {
      setError((e as Error).message);
      setCreating(false);
    }
  }

  const setClamped = (n: number) => setCount(Math.max(1, Math.min(MAX, Math.round(n) || 1)));
  const premium = engine?.ai.premium ?? false;
  const eta = premium ? `≈ ${Math.max(15, Math.ceil(count / 9) * 30)} s` : "de segundos a alguns minutos";

  return (
    <div className="space-y-8">
      {/* HERO */}
      <section className="grid gap-8 pt-4 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-zinc-700/70 bg-zinc-900/60 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.22em] text-zinc-300">
            <IconTarget size={13} /> Foco 100% no seu tema · Estilo FCC
          </span>
          <h1 className="mt-5 font-display text-[clamp(2.3rem,5.4vw,4.1rem)] font-semibold leading-[1.02] tracking-tight">
            <span className="text-metal">100% focado no tema que você precisa,</span>
            <br />
            <span className="text-zinc-500">no padrão FCC e com a letra da lei.</span>
          </h1>
          <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-zinc-400">
            Digite qualquer tema específico, artigo de lei ou disciplina: o sistema pesquisa nos grandes portais de concursos os
            pontos mais cobrados pela FCC <strong className="font-semibold text-zinc-200">estritamente dentro do seu tema</strong> e
            gera questões de nível médio 100% focadas, sem misturar assuntos vizinhos.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-3 animate-fade-up [animation-delay:120ms]">
          {[
            { icon: <IconTarget />, t: "Trava de Foco 100%", d: "Zero desvio para outros tópicos da matéria" },
            { icon: <IconGlobe />, t: "Busca nos portais", d: "Estratégia, TEC, QConcursos, Gran…" },
            { icon: <IconScale />, t: "Letra da lei", d: "Comentário focado no tema + texto legal" },
          ].map((f) => (
            <div key={f.t} className="surface rounded-2xl p-4">
              <div className="grid size-9 place-items-center rounded-xl border border-zinc-700/70 bg-zinc-900 text-zinc-200">{f.icon}</div>
              <p className="mt-3 text-sm font-semibold text-zinc-100">{f.t}</p>
              <p className="mt-1 text-xs leading-snug text-zinc-500">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ETAPA 1 */}
      <section className="surface rounded-3xl p-6 sm:p-8 animate-fade-up [animation-delay:180ms]">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <StepTitle
            n={1}
            title="Qual tema exato você precisa dominar agora?"
            subtitle="Digite um tema pontual (ex.: Crase, Atos Administrativos, Lei 14.133/2021, Art. 5º da CF) ou uma matéria. O sistema manterá foco máximo no que você informar."
          />
          <span className="inline-flex items-center gap-1.5 rounded-full border border-zinc-600/80 bg-zinc-100 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-zinc-950">
            <IconTarget size={13} /> Trava de Foco 100% Ativa
          </span>
        </div>

        <form
          className="mt-6 grid gap-3 md:grid-cols-[1.45fr_0.95fr_auto]"
          onSubmit={(e) => {
            e.preventDefault();
            void doResearch(false);
          }}
        >
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium uppercase tracking-[0.14em] text-zinc-400">
              Tema específico, lei ou matéria (Foco 100%)
            </span>
            <input
              className="field text-[15px]"
              placeholder="Ex.: Crase, Atos Administrativos, Licitações (Lei 14.133), Art. 5º da CF…"
              value={subject}
              maxLength={120}
              onChange={(e) => setSubject(e.target.value)}
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium uppercase tracking-[0.14em] text-zinc-500">Cargo / órgão (opcional)</span>
            <input
              className="field text-[15px]"
              placeholder="Ex.: Técnico Judiciário – TRT"
              value={cargo}
              maxLength={120}
              onChange={(e) => setCargo(e.target.value)}
            />
          </label>
          <div className="flex items-end">
            <button type="submit" className="btn-primary w-full md:w-auto" disabled={loading || creating}>
              {loading ? <IconRefresh className="animate-spin" /> : <IconSearch />}
              {loading ? "Pesquisando…" : "Mapear tema na FCC"}
            </button>
          </div>
        </form>

        {/* SELETOR DE SUGESTÕES: TEMAS ESPECÍFICOS (FOCO 100%) vs MATÉRIAS */}
        <div className="mt-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="inline-flex rounded-xl border border-zinc-800 bg-zinc-950/70 p-1 text-xs">
              <button
                type="button"
                onClick={() => setChipTab("temas")}
                className={`rounded-lg px-3 py-1.5 transition ${
                  chipTab === "temas" ? "bg-zinc-100 font-semibold text-zinc-950" : "text-zinc-400 hover:text-zinc-100"
                }`}
              >
                Temas específicos campeões FCC (Foco 100%)
              </button>
              <button
                type="button"
                onClick={() => setChipTab("materias")}
                className={`rounded-lg px-3 py-1.5 transition ${
                  chipTab === "materias" ? "bg-zinc-100 font-semibold text-zinc-950" : "text-zinc-400 hover:text-zinc-100"
                }`}
              >
                Disciplinas e leis completas
              </button>
            </div>
            <span className="text-[11px] text-zinc-500">Clique em uma sugestão ou digite qualquer tema acima</span>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {(chipTab === "temas" ? FOCUSED_SUGGESTIONS : SUGGESTIONS).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => {
                  setSubject(s);
                  if (chipTab === "temas") setFocusScope("laser");
                }}
                className={`rounded-full border px-3 py-1.5 text-xs transition ${
                  subject === s
                    ? "border-zinc-200 bg-zinc-100 font-semibold text-zinc-950"
                    : "border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-600 hover:text-zinc-200"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* BARRA DE GERAÇÃO DIRETA 100% FOCADA NO TEMA (1 CLIQUE) */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-zinc-800/90 bg-zinc-950/60 px-4 py-3.5">
          <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-400">
            <span className="inline-flex items-center gap-1.5 font-semibold text-zinc-200">
              <IconTarget size={14} /> Geração rápida 100% no tema:
            </span>
            <span>Quantidade por vez:</span>
            <div className="inline-flex items-center gap-1">
              {PRESETS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setCount(p)}
                  className={`rounded-md border px-2 py-0.5 text-xs transition ${
                    count === p
                      ? "border-zinc-100 bg-zinc-100 font-bold text-zinc-950"
                      : "border-zinc-800 text-zinc-400 hover:border-zinc-600 hover:text-zinc-200"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
          <button
            type="button"
            className="btn-ghost px-4 py-2 text-xs font-semibold text-zinc-100"
            onClick={() => void createQuiz(true)}
            disabled={creating || loading || subject.trim().length < 2}
          >
            <IconSpark size={14} />
            {subject.trim().length >= 2
              ? `Gerar ${count} questões 100% sobre “${subject.trim()}” agora`
              : `Gerar ${count} questões direto (100% no tema)`}
            <IconArrowRight size={14} />
          </button>
        </div>

        {error && !loading && (
          <p className="mt-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p>
        )}
      </section>

      <div ref={resultsRef} className="scroll-mt-24" />

      {/* CARREGANDO */}
      {loading && (
        <section className="surface rounded-3xl p-6 sm:p-8 animate-fade-up">
          <div className="flex items-center gap-3">
            <span className="relative grid size-10 place-items-center rounded-xl border border-zinc-700 bg-zinc-900">
              <IconGlobe className="animate-pulse-soft" />
            </span>
            <div>
              <p className="text-sm font-semibold text-zinc-100">
                Mapeando os pontos mais cobrados pela FCC 100% dentro de “{subject.trim()}”
              </p>
              <p className="text-xs text-zinc-500">{STEPS[step]}</p>
            </div>
          </div>
          <div className="mt-5 h-1.5 overflow-hidden rounded-full bg-zinc-800">
            <div className="shimmer-bar h-full rounded-full transition-all duration-700" style={{ width: `${Math.min(92, 18 + step * 15)}%` }} />
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="skeleton h-20 rounded-2xl" />
            ))}
          </div>
        </section>
      )}

      {/* ETAPA 2 */}
      {research && !loading && (
        <section className="surface rounded-3xl p-6 sm:p-8 animate-fade-up">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <StepTitle
              n={2}
              title={`Foco 100% em: ${research.subject}`}
              subtitle="Defina se todas as questões ficarão travadas no tema exato ou distribuídas entre os recortes internos abaixo."
            />
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-900/70 px-3 py-1 text-[11px] text-zinc-300">
                <IconLayers size={13} /> {METHOD_LABEL[research.method] ?? research.method}
              </span>
              {research.cached && (
                <span className="rounded-full border border-zinc-800 px-3 py-1 text-[11px] text-zinc-500">em cache (24 h)</span>
              )}
              <button type="button" className="btn-ghost px-3 py-1.5 text-xs" onClick={() => void doResearch(true)}>
                <IconRefresh size={14} /> Atualizar busca
              </button>
            </div>
          </div>

          {research.summary && <p className="mt-5 max-w-3xl text-sm leading-relaxed text-zinc-400">{research.summary}</p>}

          {/* SELETOR DE ESCOPO DE FOCO 100% */}
          <div className="mt-6 grid gap-3 md:grid-cols-2">
            <button
              type="button"
              onClick={() => setFocusScope("laser")}
              aria-pressed={focusScope === "laser"}
              className={`rounded-2xl border p-4 text-left transition ${
                focusScope === "laser"
                  ? "border-zinc-100 bg-zinc-100/[0.08] shadow-[inset_0_1px_0_rgba(255,255,255,0.15)]"
                  : "border-zinc-800 bg-zinc-950/40 hover:border-zinc-600"
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-zinc-100">
                  <IconTarget size={16} /> Modo Laser: 100% concentrado em “{research.subject}”
                </span>
                <span className="rounded-md bg-zinc-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-zinc-950">
                  100% Foco Máximo
                </span>
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                Todas as <strong>{count}</strong> questões serão geradas única e exclusivamente sobre{" "}
                <strong className="text-zinc-200">“{research.subject}”</strong>, variando apenas os ângulos de cobrança da FCC
                (literalidade, casos práticos, itens I-II-III e pegadinhas) sem sair do tema.
              </p>
            </button>

            <button
              type="button"
              onClick={() => {
                setFocusScope("recortes");
                if (!selected.length) setSelected(research.topics.slice(0, Math.min(3, research.topics.length)).map((t) => t.name));
              }}
              aria-pressed={focusScope === "recortes"}
              className={`rounded-2xl border p-4 text-left transition ${
                focusScope === "recortes"
                  ? "border-zinc-100 bg-zinc-100/[0.08] shadow-[inset_0_1px_0_rgba(255,255,255,0.15)]"
                  : "border-zinc-800 bg-zinc-950/40 hover:border-zinc-600"
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-zinc-100">
                  <IconLayers size={16} /> Modo Recortes Internos ({selected.length} selecionado{selected.length === 1 ? "" : "s"})
                </span>
                <span className="rounded-md border border-zinc-700 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-zinc-300">
                  Subtópicos do tema
                </span>
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                Você escolhe abaixo exatamente qual(is) recorte(s) interno(s) de <strong className="text-zinc-200">“{research.subject}”</strong>{" "}
                entram no caderno — ou trava 100% em um único recorte específico.
              </p>
            </button>
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-zinc-400">
              {focusScope === "laser" ? (
                <>
                  Trava Laser ativa: <strong className="text-zinc-100">100% das questões em “{research.subject}”</strong> (clique em qualquer
                  recorte abaixo se quiser focar em subtópicos específicos)
                </>
              ) : (
                <>
                  {selected.length} de {research.topics.length} recorte(s) selecionado(s)
                </>
              )}
            </p>
            <div className="flex gap-2 text-xs">
              <button
                type="button"
                className="text-zinc-400 hover:text-zinc-100"
                onClick={() => {
                  setFocusScope("recortes");
                  setSelected([research.topics[0]?.name ?? research.subject]);
                }}
              >
                Apenas o #1 mais cobrado
              </button>
              <span className="text-zinc-700">|</span>
              <button
                type="button"
                className="text-zinc-400 hover:text-zinc-100"
                onClick={() => {
                  setFocusScope("recortes");
                  setSelected(research.topics.map((t) => t.name));
                }}
              >
                Selecionar todos
              </button>
              <span className="text-zinc-700">|</span>
              <button
                type="button"
                className="text-zinc-400 hover:text-zinc-100"
                onClick={() => {
                  setFocusScope("laser");
                }}
              >
                Voltar ao Foco 100% Laser
              </button>
            </div>
          </div>

          <div className="mt-3 grid gap-3 md:grid-cols-2">
            {research.topics.map((t, i) => {
              const on = focusScope === "recortes" && selected.includes(t.name);
              const isOnlyOne = focusScope === "recortes" && selected.length === 1 && selected[0] === t.name;
              return (
                <div
                  key={t.name}
                  className={`group rounded-2xl border p-4 text-left transition ${
                    on ? "border-zinc-300/80 bg-zinc-100/[0.06]" : "border-zinc-800 bg-zinc-950/40 hover:border-zinc-600"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setFocusScope("recortes");
                        toggle(t.name);
                      }}
                      aria-pressed={on}
                      className={`mt-0.5 grid size-5 shrink-0 place-items-center rounded-md border transition ${
                        on ? "border-zinc-100 bg-zinc-100 text-zinc-950" : "border-zinc-600 text-transparent"
                      }`}
                      title="Incluir ou remover este recorte"
                    >
                      <IconCheck size={13} strokeWidth={2.6} />
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setFocusScope("recortes");
                            toggle(t.name);
                          }}
                          className="flex flex-wrap items-center gap-2 text-left"
                        >
                          <span className="font-display text-[11px] text-zinc-500">#{i + 1}</span>
                          <span className="text-sm font-semibold text-zinc-100">{t.name}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => lockSingleTopic(t.name)}
                          className={`rounded-lg border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider transition ${
                            isOnlyOne
                              ? "border-zinc-100 bg-zinc-100 text-zinc-950"
                              : "border-zinc-700/80 bg-zinc-900 text-zinc-300 hover:border-zinc-400 hover:text-white"
                          }`}
                        >
                          {isOnlyOne ? "Foco 100% neste ponto" : "Focar 100% só aqui"}
                        </button>
                      </div>
                      {t.why && <p className="mt-1 text-xs leading-relaxed text-zinc-500">{t.why}</p>}
                      <div className="mt-3 flex items-center gap-3">
                        <div className="h-1 flex-1 overflow-hidden rounded-full bg-zinc-800">
                          <div className="h-full rounded-full bg-linear-to-r from-zinc-500 to-zinc-100" style={{ width: `${Math.max(4, t.relevance)}%` }} />
                        </div>
                        {t.relevance > 0 && (
                          <span className={`rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${LEVEL_STYLE[t.level]}`}>{t.level}</span>
                        )}
                        {t.sources.length > 0 && (
                          <span className="text-[10px] text-zinc-500">fontes {t.sources.map((s) => `[${s}]`).join(" ")}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <form
            className="mt-4 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              setFocusScope("recortes");
              addCustom();
            }}
          >
            <input
              className="field py-2.5 text-sm"
              placeholder="Adicionar um recorte específico personalizado (ex.: Art. 37, XI – Teto remuneratório)"
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              maxLength={140}
            />
            <button type="submit" className="btn-ghost shrink-0 text-sm">
              <IconPlus size={16} /> Adicionar
            </button>
          </form>

          <div className="mt-8 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
            <div>
              <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-500">
                <IconGlobe size={14} /> Fontes consultadas nos portais
              </h3>
              {research.sources.length ? (
                <ol className="mt-3 space-y-2">
                  {research.sources.map((s) => (
                    <li key={s.id} className="surface-soft flex gap-3 rounded-xl p-3">
                      <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-zinc-800 text-[11px] font-bold text-zinc-200">
                        {initials(s.portal) || s.id}
                      </span>
                      <div className="min-w-0">
                        <a href={s.url} target="_blank" rel="noopener noreferrer" className="group inline-flex items-start gap-1 text-sm font-medium text-zinc-200 hover:text-white">
                          <span className="line-clamp-1">[{s.id}] {s.title}</span>
                          <IconExternal size={13} className="mt-0.5 shrink-0 text-zinc-500 group-hover:text-zinc-200" />
                        </a>
                        <p className="text-[11px] text-zinc-500">
                          {s.portal} · via {s.engine}
                        </p>
                        {s.snippet && <p className="mt-1 line-clamp-2 text-xs text-zinc-500">{s.snippet}</p>}
                      </div>
                    </li>
                  ))}
                </ol>
              ) : (
                <p className="mt-3 rounded-xl border border-zinc-800 p-4 text-xs leading-relaxed text-zinc-500">
                  Os buscadores não retornaram páginas dos portais nesta tentativa (limites temporários dos serviços de busca). O
                  recorte foi elaborado 100% focado no seu tema a partir do histórico da banca FCC.
                </p>
              )}
              {research.searchLog.length > 0 && (
                <button type="button" onClick={() => setShowLog((v) => !v)} className="mt-3 text-[11px] text-zinc-500 underline-offset-4 hover:text-zinc-300 hover:underline">
                  {showLog ? "Ocultar" : "Ver"} registro da busca
                </button>
              )}
              {showLog && (
                <ul className="mt-2 space-y-1 rounded-xl border border-zinc-800 bg-black/40 p-3 font-mono text-[11px] text-zinc-500">
                  {research.searchLog.map((l, i) => (
                    <li key={i}>› {l}</li>
                  ))}
                </ul>
              )}
            </div>
            <div>
              <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-500">
                <IconBook size={14} /> Como a FCC cobra “{research.subject}”
              </h3>
              <ul className="mt-3 space-y-2">
                {research.styleTips.map((tip, i) => (
                  <li key={i} className="flex gap-3 rounded-xl border border-zinc-800/80 bg-zinc-950/40 p-3 text-xs leading-relaxed text-zinc-400">
                    <span className="font-display text-sm text-zinc-200">{String(i + 1).padStart(2, "0")}</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      )}

      {/* ETAPA 3 */}
      {research && !loading && (
        <section className="surface rounded-3xl p-6 sm:p-8 animate-fade-up">
          <StepTitle n={3} title="Configure o seu caderno de questões" subtitle="Escolha quantas questões gerar por vez e confira a distribuição 100% focada no seu tema." />
          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-zinc-500">Quantidade de questões por vez</p>
              <div className="mt-4 flex items-center gap-4">
                <button type="button" className="btn-ghost p-2.5" onClick={() => setClamped(count - 1)} aria-label="Diminuir">
                  <IconMinus />
                </button>
                <input
                  type="number"
                  min={1}
                  max={MAX}
                  value={count}
                  onChange={(e) => setClamped(Number(e.target.value))}
                  className="w-24 bg-transparent text-center font-display text-5xl font-semibold text-zinc-50 outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none"
                  aria-label="Quantidade de questões"
                />
                <button type="button" className="btn-ghost p-2.5" onClick={() => setClamped(count + 1)} aria-label="Aumentar">
                  <IconPlus />
                </button>
              </div>
              <input
                type="range"
                min={1}
                max={MAX}
                value={count}
                onChange={(e) => setClamped(Number(e.target.value))}
                className="mt-5 w-full accent-zinc-200"
                aria-label="Controle deslizante da quantidade"
              />
              <div className="mt-4 flex flex-wrap gap-2">
                {PRESETS.map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setCount(p)}
                    className={`rounded-lg border px-3.5 py-1.5 text-sm transition ${
                      count === p ? "border-zinc-100 bg-zinc-100 font-semibold text-zinc-950" : "border-zinc-800 text-zinc-400 hover:border-zinc-600 hover:text-zinc-100"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
              <p className="mt-4 flex items-center gap-1.5 text-[11px] text-zinc-500">
                <IconClock size={13} /> Tempo estimado de geração: {eta}. Máximo de {MAX} por lote.
              </p>
              {engine && !premium && (
                <p className="mt-3 rounded-xl border border-zinc-800 bg-black/30 p-3 text-[11px] leading-relaxed text-zinc-500">
                  Modo gratuito com Trava de Foco 100%: só entram questões do banco curado ({engine.bankSize} questões com letra da
                  lei conferida) que correspondam estritamente ao tema escolhido; as demais são geradas por IA 100% focada no seu tema.
                </p>
              )}
            </div>

            <div className="space-y-4">
              <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-zinc-500">Modo de correção</p>
                <div className="mt-4 grid gap-3">
                  {(
                    [
                      { v: "estudo", t: "Modo Estudo", d: "Responda e veja na hora o gabarito, a letra da lei e o comentário focado no tema." },
                      { v: "simulado", t: "Modo Simulado", d: "Responda tudo como na prova. A correção comentada de todas as questões aparece ao final." },
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.v}
                      type="button"
                      onClick={() => setMode(m.v)}
                      aria-pressed={mode === m.v}
                      className={`rounded-xl border p-4 text-left transition ${
                        mode === m.v ? "border-zinc-300/80 bg-zinc-100/[0.06]" : "border-zinc-800 hover:border-zinc-600"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`grid size-4 place-items-center rounded-full border ${mode === m.v ? "border-zinc-100" : "border-zinc-600"}`}>
                          {mode === m.v && <span className="size-2 rounded-full bg-zinc-100" />}
                        </span>
                        <span className="text-sm font-semibold text-zinc-100">{m.t}</span>
                      </div>
                      <p className="mt-1.5 pl-6 text-xs leading-relaxed text-zinc-500">{m.d}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* DISTRIBUIÇÃO GARANTIDA (TRAVA DE FOCO 100%) */}
              <div className="rounded-2xl border border-zinc-700/80 bg-zinc-950/60 p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-300">
                    <IconTarget size={13} /> Distribuição garantida do caderno (100% no tema)
                  </p>
                  <span className="rounded bg-zinc-100 px-2 py-0.5 text-[10px] font-bold text-zinc-950">100% focado</span>
                </div>
                <ul className="mt-3 space-y-1.5 text-xs">
                  {distribution.map((d) => (
                    <li key={d.topic} className="flex items-center justify-between gap-3 rounded-lg bg-zinc-900/70 px-3 py-1.5">
                      <span className="truncate text-zinc-200">{d.topic}</span>
                      <span className="shrink-0 font-semibold text-zinc-100">
                        {d.qty} {d.qty === 1 ? "questão" : "questões"} ({d.pct}%)
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {error && <p className="mt-5 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p>}

          <div className="mt-6 flex flex-col items-start justify-between gap-4 border-t border-zinc-800/80 pt-6 sm:flex-row sm:items-center">
            <p className="text-sm text-zinc-400">
              <span className="font-semibold text-zinc-100">{count}</span> questões ·{" "}
              <span className="font-semibold text-zinc-100">100% focadas em “{research.subject}”</span> ·{" "}
              {mode === "estudo" ? "Modo Estudo" : "Modo Simulado"} · nível médio · estilo FCC
            </p>
            <button type="button" className="btn-primary px-6 text-[15px]" onClick={() => void createQuiz(false)} disabled={creating || !effectiveTopics.length}>
              {creating ? <IconRefresh className="animate-spin" /> : <IconSpark />}
              {creating ? "Preparando…" : `Gerar ${count} questões 100% focadas`}
              {!creating && <IconArrowRight size={16} />}
            </button>
          </div>
        </section>
      )}
    </div>
  );
}

function StepTitle({ n, title, subtitle }: { n: number; title: string; subtitle: string }) {
  return (
    <div className="flex items-start gap-4">
      <span className="grid size-10 shrink-0 place-items-center rounded-xl border border-zinc-700 bg-linear-to-b from-zinc-800 to-zinc-950 font-display text-lg font-semibold text-zinc-100">
        {n}
      </span>
      <div>
        <h2 className="font-display text-2xl font-semibold tracking-tight text-zinc-50">{title}</h2>
        <p className="mt-1 text-sm text-zinc-500">{subtitle}</p>
      </div>
    </div>
  );
}
