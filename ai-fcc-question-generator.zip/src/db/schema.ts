import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import type { Letter, Options, PlanItem, ResearchSource, ResearchTopic } from "../lib/types";

/** Cache/histórico das pesquisas de "assuntos mais cobrados". */
export const researches = pgTable(
  "researches",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    subject: text("subject").notNull(),
    subjectKey: text("subject_key").notNull(),
    cargo: text("cargo"),
    topics: jsonb("topics").$type<ResearchTopic[]>().notNull(),
    sources: jsonb("sources").$type<ResearchSource[]>().notNull(),
    summary: text("summary"),
    styleTips: jsonb("style_tips").$type<string[]>(),
    searchLog: jsonb("search_log").$type<string[]>(),
    method: text("method").notNull(),
    engine: text("engine").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("researches_subject_key_idx").on(t.subjectKey)],
);

/** Um simulado (lote de questões geradas de uma vez). */
export const quizzes = pgTable("quizzes", {
  id: uuid("id").primaryKey().defaultRandom(),
  subject: text("subject").notNull(),
  cargo: text("cargo"),
  researchId: uuid("research_id"),
  topics: jsonb("topics").$type<string[]>().notNull(),
  plan: jsonb("plan").$type<PlanItem[]>().notNull(),
  questionCount: integer("question_count").notNull(),
  mode: text("mode").notNull(),
  status: text("status").notNull().default("generating"),
  answeredCount: integer("answered_count").notNull().default(0),
  correctCount: integer("correct_count").notNull().default(0),
  engine: text("engine"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
});

/** Questões com gabarito e comentários (nunca enviados ao cliente antes da resposta). */
export const questions = pgTable(
  "questions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    quizId: uuid("quiz_id")
      .notNull()
      .references(() => quizzes.id, { onDelete: "cascade" }),
    position: integer("position").notNull(),
    topic: text("topic").notNull(),
    supportText: text("support_text"),
    statement: text("statement").notNull(),
    options: jsonb("options").$type<Options>().notNull(),
    correct: text("correct").$type<Letter>().notNull(),
    summary: text("summary").notNull(),
    legalBasis: text("legal_basis"),
    lawText: text("law_text"),
    lawUrl: text("law_url"),
    analysis: jsonb("analysis").$type<Partial<Record<Letter, string>>>().notNull(),
    tip: text("tip"),
    difficulty: text("difficulty"),
    origin: text("origin").notNull(),
    engine: text("engine"),
    bankId: text("bank_id"),
    userAnswer: text("user_answer").$type<Letter>(),
    isCorrect: boolean("is_correct"),
    answeredAt: timestamp("answered_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("questions_quiz_position_idx").on(t.quizId, t.position)],
);
