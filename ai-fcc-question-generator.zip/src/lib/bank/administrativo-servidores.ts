import { mk } from "./make";

export const ADMINISTRATIVO_SERVIDORES = [
  /* =========================== DIREITO ADMINISTRATIVO =========================== */
  mk({
    id: "adm-atos-01",
    subject: "administrativo",
    topic: "Atos administrativos: atributos, elementos e extinção",
    statement: "A respeito da anulação e da revogação dos atos administrativos, é correto afirmar:",
    options: [
      "A revogação decorre de vício de legalidade e produz efeitos retroativos (ex tunc).",
      "A anulação pode ser feita pela própria Administração ou pelo Poder Judiciário, ao passo que a revogação, por razões de conveniência e oportunidade, é privativa da Administração que praticou o ato.",
      "O Poder Judiciário, no exercício da função jurisdicional, pode revogar atos administrativos do Poder Executivo que considere inoportunos.",
      "A Administração pode revogar atos vinculados sempre que houver interesse público superveniente.",
      "A anulação dos atos administrativos de que decorram efeitos favoráveis aos destinatários pode ser feita a qualquer tempo, ainda que o beneficiário esteja de boa-fé.",
    ],
    correct: "B",
    summary:
      "Anulação é a retirada do ato por ilegalidade: pode ser feita pela Administração (autotutela) ou pelo Judiciário e, em regra, produz efeitos ex tunc. Revogação é a retirada de ato válido por conveniência e oportunidade (mérito): somente a própria Administração pode revogar seus atos, com efeitos ex nunc, respeitados os direitos adquiridos. Atos vinculados não podem ser revogados, e o direito de anular atos favoráveis decai em 5 anos, salvo má-fé.",
    legalBasis: "Lei nº 9.784/1999, arts. 53 e 54; Súmula 473 do STF",
    lawText:
      "Art. 53. A Administração deve anular seus próprios atos, quando eivados de vício de legalidade, e pode revogá-los por motivo de conveniência ou oportunidade, respeitados os direitos adquiridos.\nArt. 54. O direito da Administração de anular os atos administrativos de que decorram efeitos favoráveis para os destinatários decai em cinco anos, contados da data em que foram praticados, salvo comprovada má-fé.",
    analysis: [
      "Errada. A descrição corresponde à anulação; a revogação atinge ato válido e opera efeitos ex nunc.",
      "Correta. A anulação pode ser administrativa ou judicial; a revogação é exclusiva da Administração.",
      "Errada. No exercício da jurisdição, o Judiciário controla apenas a legalidade; ele só revoga os próprios atos administrativos (função atípica).",
      "Errada. Atos vinculados não comportam juízo de mérito e, por isso, não podem ser revogados.",
      "Errada. Há prazo decadencial de 5 anos, salvo comprovada má-fé (art. 54).",
    ],
    tip: "Súmula 473 do STF: a Administração pode anular seus atos ilegais ou revogá-los por conveniência ou oportunidade, respeitados os direitos adquiridos e ressalvada a apreciação judicial.",
  }),
  mk({
    id: "adm-poderes-01",
    subject: "administrativo",
    topic: "Poderes administrativos",
    statement:
      "A interdição de um restaurante pela vigilância sanitária municipal, em razão do descumprimento de normas de higiene, constitui exemplo típico de exercício do poder",
    options: ["hierárquico.", "disciplinar.", "de polícia.", "regulamentar.", "de autotutela."],
    correct: "C",
    summary:
      "O poder de polícia é a atividade estatal que limita ou disciplina direitos, interesses e liberdades individuais em benefício do interesse público (higiene, segurança, ordem etc.). A interdição de estabelecimento por descumprimento de normas sanitárias atinge o particular que tem apenas vínculo geral com o Estado, o que caracteriza o poder de polícia, dotado de discricionariedade (em regra), autoexecutoriedade e coercibilidade.",
    legalBasis: "Código Tributário Nacional (Lei nº 5.172/1966), art. 78",
    lawText:
      "Art. 78. Considera-se poder de polícia atividade da administração pública que, limitando ou disciplinando direito, interêsse ou liberdade, regula a prática de ato ou abstenção de fato, em razão de interêsse público concernente à segurança, à higiene, à ordem, aos costumes, à disciplina da produção e do mercado, ao exercício de atividades econômicas dependentes de concessão ou autorização do Poder Público, à tranqüilidade pública ou ao respeito à propriedade e aos direitos individuais ou coletivos.",
    analysis: [
      "Errada. O poder hierárquico se refere às relações internas de subordinação (ordenar, fiscalizar, delegar, avocar).",
      "Errada. O poder disciplinar pune servidores e particulares com vínculo especial com a Administração (ex.: contratados).",
      "Correta. Restrição à atividade do particular em nome da higiene pública: poder de polícia.",
      "Errada. O poder regulamentar consiste em editar atos normativos para a fiel execução das leis.",
      "Errada. Autotutela é o princípio pelo qual a Administração revê os próprios atos, não a atuação sobre particulares.",
    ],
    tip: "Distinção preferida da FCC: vínculo geral com o particular = poder de polícia; vínculo especial (servidor, contratado) = poder disciplinar.",
    difficulty: "Fácil",
  }),
  mk({
    id: "adm-organizacao-01",
    subject: "administrativo",
    topic: "Organização administrativa",
    statement: "Sobre a organização da Administração Pública, é correto afirmar que",
    options: [
      "a desconcentração consiste na distribuição de competências a pessoas jurídicas distintas, criadas pelo Estado.",
      "as autarquias são pessoas jurídicas de direito público, criadas por lei específica, para executar atividades típicas da Administração Pública.",
      "as empresas públicas e as sociedades de economia mista são criadas diretamente por lei específica, dispensada qualquer outra providência.",
      "os órgãos públicos possuem personalidade jurídica própria e respondem diretamente pelos danos que causarem.",
      "a sociedade de economia mista deve ter capital exclusivamente público e pode adotar qualquer forma societária.",
    ],
    correct: "B",
    summary:
      "Autarquias são pessoas jurídicas de direito público criadas diretamente por lei específica para desempenhar atividades típicas de Estado com gestão descentralizada. Já empresas públicas e sociedades de economia mista têm apenas a criação AUTORIZADA por lei, dependendo do registro de seus atos constitutivos. Desconcentração é a distribuição interna de competências entre órgãos da mesma pessoa jurídica, e órgãos não têm personalidade jurídica.",
    legalBasis: "CF/1988, art. 37, XIX; Decreto-Lei nº 200/1967, art. 5º, I",
    lawText:
      "CF, art. 37, XIX - somente por lei específica poderá ser criada autarquia e autorizada a instituição de empresa pública, de sociedade de economia mista e de fundação, cabendo à lei complementar, neste último caso, definir as áreas de sua atuação;\nDL nº 200/1967, art. 5º, I - Autarquia - o serviço autônomo, criado por lei, com personalidade jurídica, patrimônio e receita próprios, para executar atividades típicas da Administração Pública, que requeiram, para seu melhor funcionamento, gestão administrativa e financeira descentralizada.",
    analysis: [
      "Errada. O conceito é de descentralização; a desconcentração ocorre dentro da mesma pessoa jurídica, entre órgãos.",
      "Correta. Conforme o art. 37, XIX, da CF e o art. 5º, I, do DL nº 200/1967.",
      "Errada. A lei apenas autoriza a instituição; a personalidade jurídica surge com o registro dos atos constitutivos.",
      "Errada. Órgãos são centros de competência despersonalizados; responde a pessoa jurídica a que pertencem.",
      "Errada. A sociedade de economia mista tem capital público e privado (com controle estatal) e deve ser sociedade anônima.",
    ],
    tip: "Lei CRIA autarquia; lei AUTORIZA empresa pública, sociedade de economia mista e fundação.",
  }),
  mk({
    id: "adm-responsabilidade-01",
    subject: "administrativo",
    topic: "Responsabilidade civil do Estado",
    statement:
      "Um ônibus de empresa concessionária de serviço público de transporte coletivo colidiu com um veículo particular, causando danos ao seu proprietário. Segundo a Constituição Federal, a responsabilidade da concessionária pelos danos causados é",
    options: [
      "subjetiva, dependendo da comprovação de dolo ou culpa do motorista.",
      "objetiva, assegurado o direito de regresso contra o motorista nos casos de dolo ou culpa.",
      "inexistente, pois somente as pessoas jurídicas de direito público respondem objetivamente.",
      "objetiva, sendo vedado o direito de regresso contra o motorista.",
      "subsidiária, cabendo ao poder concedente responder primeiramente pelo dano.",
    ],
    correct: "B",
    summary:
      "As pessoas jurídicas de direito público e as de direito privado prestadoras de serviços públicos (como as concessionárias) respondem objetivamente pelos danos que seus agentes, nessa qualidade, causarem a terceiros (teoria do risco administrativo). Basta comprovar conduta, dano e nexo causal. O dolo ou a culpa do agente só importa na ação regressiva movida contra ele.",
    legalBasis: "CF/1988, art. 37, § 6º",
    lawText:
      "§ 6º As pessoas jurídicas de direito público e as de direito privado prestadoras de serviços públicos responderão pelos danos que seus agentes, nessa qualidade, causarem a terceiros, assegurado o direito de regresso contra o responsável nos casos de dolo ou culpa.",
    analysis: [
      "Errada. A responsabilidade da concessionária é objetiva; dolo ou culpa só são exigidos na ação de regresso.",
      "Correta. Responsabilidade objetiva, com direito de regresso contra o agente em caso de dolo ou culpa.",
      "Errada. As prestadoras de serviço público, ainda que de direito privado, também respondem objetivamente.",
      "Errada. O regresso é expressamente assegurado pela Constituição.",
      "Errada. A concessionária responde diretamente; o poder concedente responde apenas subsidiariamente.",
    ],
    tip: "O STF (RE 591.874) firmou que a responsabilidade objetiva da concessionária alcança também terceiros não usuários do serviço.",
  }),
  mk({
    id: "adm-improbidade-01",
    subject: "administrativo",
    topic: "Improbidade administrativa (Lei nº 8.429/1992)",
    statement: "Com as alterações promovidas pela Lei nº 14.230/2021 na Lei nº 8.429/1992, os atos de improbidade administrativa",
    options: [
      "podem ser praticados na modalidade culposa quando causarem prejuízo ao erário.",
      "exigem conduta dolosa, não bastando a voluntariedade do agente.",
      "dispensam a demonstração de dolo quando atentarem contra os princípios da Administração Pública.",
      "são imprescritíveis quando causarem enriquecimento ilícito.",
      "somente podem ser praticados por agentes públicos ocupantes de cargo efetivo.",
    ],
    correct: "B",
    summary:
      "Após a Lei nº 14.230/2021, somente condutas dolosas configuram improbidade administrativa, inclusive nos atos que causam lesão ao erário (art. 10), cuja modalidade culposa foi extinta. O dolo exigido é a vontade livre e consciente de alcançar o resultado ilícito, não bastando a mera voluntariedade. A ação prescreve em 8 anos.",
    legalBasis: "Lei nº 8.429/1992, art. 1º, §§ 1º e 2º (redação da Lei nº 14.230/2021)",
    lawText:
      "§ 1º Consideram-se atos de improbidade administrativa as condutas dolosas tipificadas nos arts. 9º, 10 e 11 desta Lei, ressalvados tipos previstos em leis especiais.\n§ 2º Considera-se dolo a vontade livre e consciente de alcançar o resultado ilícito tipificado nos arts. 9º, 10 e 11 desta Lei, não bastando a voluntariedade do agente.",
    analysis: [
      "Errada. A modalidade culposa foi suprimida; todos os atos de improbidade exigem dolo.",
      "Correta. Reprodução dos §§ 1º e 2º do art. 1º.",
      "Errada. Os atos do art. 11 (violação a princípios) também exigem dolo.",
      "Errada. A ação para aplicar as sanções prescreve em 8 anos (art. 23).",
      "Errada. A lei alcança agentes públicos em sentido amplo, inclusive transitórios e sem remuneração, e particulares que induzam ou concorram dolosamente para o ato.",
    ],
    tip: "Pós-2021: improbidade é sempre dolosa, e a prescrição é de 8 anos. A FCC adora cobrar a extinção da modalidade culposa.",
  }),

  /* ============================== LEI Nº 8.112/1990 ============================== */
  mk({
    id: "l8112-provimento-01",
    subject: "lei8112",
    topic: "Provimento, posse e exercício",
    statement:
      "Carlos, servidor público federal estável, tomou posse em outro cargo inacumulável e, durante o estágio probatório relativo ao novo cargo, foi considerado inabilitado. Nos termos da Lei nº 8.112/1990, Carlos deverá retornar ao cargo anteriormente ocupado por meio de",
    options: ["reintegração.", "reversão.", "aproveitamento.", "recondução.", "readaptação."],
    correct: "D",
    summary:
      "Recondução é o retorno do servidor estável ao cargo anteriormente ocupado e ocorre em duas hipóteses: inabilitação em estágio probatório relativo a outro cargo ou reintegração do anterior ocupante. Como Carlos era estável e foi inabilitado no estágio do novo cargo, ele será reconduzido.",
    legalBasis: "Lei nº 8.112/1990, art. 29",
    lawText:
      "Art. 29. Recondução é o retorno do servidor estável ao cargo anteriormente ocupado e decorrerá de:\nI - inabilitação em estágio probatório relativo a outro cargo;\nII - reintegração do anterior ocupante.",
    analysis: [
      "Errada. Reintegração é a reinvestidura do servidor estável quando invalidada sua demissão (art. 28).",
      "Errada. Reversão é o retorno à atividade do servidor aposentado (art. 25).",
      "Errada. Aproveitamento é o retorno do servidor posto em disponibilidade (art. 30).",
      "Correta. Inabilitação em estágio probatório de outro cargo gera recondução (art. 29, I).",
      "Errada. Readaptação é a investidura em cargo compatível com limitação física ou mental (art. 24).",
    ],
    tip: "Associe: Reintegração = demissão invalidada; Reversão = aposentado; Aproveitamento = disponibilidade; Recondução = inabilitação/reintegração do anterior ocupante.",
    difficulty: "Fácil",
  }),
  mk({
    id: "l8112-prazos-01",
    subject: "lei8112",
    topic: "Provimento, posse e exercício",
    statement:
      "De acordo com a Lei nº 8.112/1990, a posse ocorrerá no prazo de ..... contados da publicação do ato de provimento, e é de ..... o prazo para o servidor empossado em cargo público entrar em exercício, contados da data da posse.\nPreenchem, correta e respectivamente, as lacunas:",
    options: ["trinta dias − quinze dias", "quinze dias − trinta dias", "trinta dias − trinta dias", "sessenta dias − quinze dias", "quinze dias − quinze dias"],
    correct: "A",
    summary:
      "A posse deve ocorrer em até 30 dias da publicação do ato de provimento; se não ocorrer, o ato de provimento será tornado sem efeito. Empossado, o servidor tem 15 dias para entrar em exercício; se não o fizer, será exonerado do cargo.",
    legalBasis: "Lei nº 8.112/1990, art. 13, § 1º, e art. 15, § 1º",
    lawText:
      "Art. 13, § 1º A posse ocorrerá no prazo de trinta dias contados da publicação do ato de provimento.\nArt. 15, § 1º É de quinze dias o prazo para o servidor empossado em cargo público entrar em exercício, contados da data da posse.",
    analysis: [
      "Correta. 30 dias para a posse e 15 dias para o exercício.",
      "Errada. Os prazos estão invertidos.",
      "Errada. O prazo para entrar em exercício é de 15 dias.",
      "Errada. O prazo para a posse é de 30 dias.",
      "Errada. O prazo para a posse é de 30 dias.",
    ],
    tip: "Consequências cobradas pela FCC: sem posse no prazo → provimento tornado sem efeito (art. 13, § 6º); sem exercício no prazo → exoneração (art. 15, § 2º).",
    difficulty: "Fácil",
  }),
  mk({
    id: "l8112-suspensao-01",
    subject: "lei8112",
    topic: "Penalidades disciplinares",
    statement: "Nos termos da Lei nº 8.112/1990, a penalidade de suspensão",
    options: [
      "será aplicada em caso de reincidência das faltas punidas com advertência, não podendo exceder de 90 dias.",
      "não poderá exceder de 30 dias e terá seu registro cancelado após 3 anos de efetivo exercício.",
      "é incompatível com a conversão em multa, ainda que haja conveniência para o serviço.",
      "será aplicada por escrito, exclusivamente nos casos de inobservância de dever funcional.",
      "terá seu registro cancelado após 10 anos, se o servidor não houver praticado nova infração.",
    ],
    correct: "A",
    summary:
      "A suspensão é aplicada em caso de reincidência de faltas punidas com advertência e de violação das demais proibições que não tipifiquem infração sujeita a demissão, com limite de 90 dias. Havendo conveniência para o serviço, pode ser convertida em multa de 50% por dia de vencimento ou remuneração. Seu registro é cancelado após 5 anos de efetivo exercício sem nova infração.",
    legalBasis: "Lei nº 8.112/1990, arts. 130 e 131",
    lawText:
      "Art. 130. A suspensão será aplicada em caso de reincidência das faltas punidas com advertência e de violação das demais proibições que não tipifiquem infração sujeita a penalidade de demissão, não podendo exceder de 90 (noventa) dias.\n§ 2º Quando houver conveniência para o serviço, a penalidade de suspensão poderá ser convertida em multa, na base de 50% (cinqüenta por cento) por dia de vencimento ou remuneração, ficando o servidor obrigado a permanecer em serviço.\nArt. 131. As penalidades de advertência e de suspensão terão seus registros cancelados, após o decurso de 3 (três) e 5 (cinco) anos de efetivo exercício, respectivamente, se o servidor não houver, nesse período, praticado nova infração disciplinar.",
    analysis: [
      "Correta. Literalidade do art. 130, caput.",
      "Errada. O limite é de 90 dias, e o cancelamento ocorre após 5 anos (3 anos é o prazo da advertência).",
      "Errada. A conversão em multa é expressamente admitida (art. 130, § 2º).",
      "Errada. A aplicação por escrito, para inobservância de dever funcional, descreve a advertência (art. 129).",
      "Errada. O prazo de cancelamento da suspensão é de 5 anos.",
    ],
    tip: "Suspensão de até 30 dias pode resultar de sindicância; acima de 30 dias exige processo administrativo disciplinar (arts. 145 e 146).",
  }),
  mk({
    id: "l8112-prescricao-01",
    subject: "lei8112",
    topic: "Penalidades disciplinares",
    statement: "Segundo a Lei nº 8.112/1990, a ação disciplinar prescreverá em",
    options: [
      "5 anos quanto às infrações puníveis com demissão, 2 anos quanto à suspensão e 180 dias quanto à advertência.",
      "5 anos quanto às infrações puníveis com demissão, 3 anos quanto à suspensão e 1 ano quanto à advertência.",
      "10 anos quanto às infrações puníveis com demissão, 5 anos quanto à suspensão e 2 anos quanto à advertência.",
      "2 anos quanto às infrações puníveis com demissão, 1 ano quanto à suspensão e 180 dias quanto à advertência.",
      "5 anos para todas as penalidades disciplinares, contados da data do fato.",
    ],
    correct: "A",
    summary:
      "A Lei nº 8.112/1990 fixa prazos prescricionais distintos conforme a gravidade da penalidade: 5 anos (demissão, cassação de aposentadoria ou disponibilidade e destituição de cargo em comissão), 2 anos (suspensão) e 180 dias (advertência). O prazo começa a correr da data em que o fato se tornou conhecido, e não da data do fato.",
    legalBasis: "Lei nº 8.112/1990, art. 142",
    lawText:
      "Art. 142. A ação disciplinar prescreverá:\nI - em 5 (cinco) anos, quanto às infrações puníveis com demissão, cassação de aposentadoria ou disponibilidade e destituição de cargo em comissão;\nII - em 2 (dois) anos, quanto à suspensão;\nIII - em 180 (cento e oitenta) dias, quanto à advertência.\n§ 1º O prazo de prescrição começa a correr da data em que o fato se tornou conhecido.",
    analysis: [
      "Correta. Prazos do art. 142, I a III.",
      "Errada. Suspensão prescreve em 2 anos, e advertência, em 180 dias.",
      "Errada. Todos os prazos estão incorretos.",
      "Errada. Infrações puníveis com demissão prescrevem em 5 anos.",
      "Errada. Os prazos variam conforme a penalidade e são contados da data em que o fato se tornou conhecido.",
    ],
    tip: "A abertura de sindicância ou a instauração de PAD interrompe a prescrição até a decisão final (art. 142, § 3º).",
  }),
  mk({
    id: "l8112-concessoes-01",
    subject: "lei8112",
    topic: "Direitos e vantagens: férias, licenças e concessões",
    statement:
      "Joana, servidora pública federal, pretende ausentar-se do serviço sem qualquer prejuízo. Nos termos da Lei nº 8.112/1990, ela poderá ausentar-se por",
    options: [
      "1 dia, para doação de sangue.",
      "5 dias consecutivos, em razão de casamento.",
      "3 dias, para alistamento eleitoral, independentemente de comprovação.",
      "8 dias consecutivos, em razão do falecimento de tio.",
      "2 dias, para doação de sangue, a cada semestre.",
    ],
    correct: "A",
    summary:
      "O art. 97 prevê as concessões: ausência de 1 dia para doação de sangue; pelo período comprovadamente necessário para alistamento ou recadastramento eleitoral, limitado a 2 dias; e 8 dias consecutivos em razão de casamento (gala) ou falecimento de cônjuge, companheiro, pais, madrasta ou padrasto, filhos, enteados, menor sob guarda ou tutela e irmãos (nojo). Tios não estão no rol.",
    legalBasis: "Lei nº 8.112/1990, art. 97",
    lawText:
      "Art. 97. Sem qualquer prejuízo, poderá o servidor ausentar-se do serviço:\nI - por 1 (um) dia, para doação de sangue;\nII - pelo período comprovadamente necessário para alistamento ou recadastramento eleitoral, limitado, em qualquer caso, a 2 (dois) dias; e\nIII - por 8 (oito) dias consecutivos em razão de:\na) casamento;\nb) falecimento do cônjuge, companheiro, pais, madrasta ou padrasto, filhos, enteados, menor sob guarda ou tutela e irmãos.",
    analysis: [
      "Correta. Art. 97, I.",
      "Errada. Em razão de casamento, a ausência é de 8 dias consecutivos.",
      "Errada. É pelo período comprovadamente necessário, limitado a 2 dias.",
      "Errada. O falecimento de tio não está previsto no rol do art. 97, III, b.",
      "Errada. A lei prevê 1 dia para doação de sangue.",
    ],
    tip: "Gala (casamento) e nojo (falecimento) = 8 dias consecutivos. A FCC costuma incluir parentes fora do rol, como tios, avós e sogros.",
  }),
  mk({
    id: "l8112-pad-01",
    subject: "lei8112",
    topic: "Processo administrativo disciplinar e sindicância",
    statement: "De acordo com a Lei nº 8.112/1990, o processo disciplinar será conduzido por comissão composta de",
    options: [
      "três servidores estáveis designados pela autoridade competente, e o prazo para sua conclusão não excederá 60 dias, admitida a prorrogação por igual prazo.",
      "dois servidores estáveis e um ocupante de cargo em comissão, com prazo de conclusão de 30 dias, improrrogável.",
      "três servidores, estáveis ou não, com prazo de conclusão de 120 dias, prorrogável uma vez.",
      "cinco servidores estáveis, com prazo de conclusão de 60 dias, improrrogável.",
      "três servidores estáveis, com prazo de conclusão de 30 dias, prorrogável por igual período.",
    ],
    correct: "A",
    summary:
      "O PAD é conduzido por comissão de três servidores estáveis designados pela autoridade competente, que indicará o presidente entre eles. O prazo de conclusão é de até 60 dias, contados da publicação do ato que constituir a comissão, admitida prorrogação por igual prazo. O prazo de 30 dias, prorrogável por igual período, é o da sindicância.",
    legalBasis: "Lei nº 8.112/1990, arts. 149 e 152",
    lawText:
      "Art. 149. O processo disciplinar será conduzido por comissão composta de três servidores estáveis designados pela autoridade competente, observado o disposto no § 3º do art. 143, que indicará, dentre eles, o seu presidente, que deverá ser ocupante de cargo efetivo superior ou de mesmo nível, ou ter nível de escolaridade igual ou superior ao do indiciado.\nArt. 152. O prazo para a conclusão do processo disciplinar não excederá 60 (sessenta) dias, contados da data de publicação do ato que constituir a comissão, admitida a sua prorrogação por igual prazo, quando as circunstâncias o exigirem.",
    analysis: [
      "Correta. Três servidores estáveis; 60 dias, prorrogáveis por igual prazo.",
      "Errada. Todos os membros devem ser servidores estáveis, e o prazo é de 60 dias, prorrogável.",
      "Errada. Os membros devem ser estáveis, e o prazo é de 60 dias.",
      "Errada. A comissão tem três membros, e o prazo admite prorrogação.",
      "Errada. O prazo de 30 dias, prorrogável por igual período, refere-se à sindicância (art. 145, parágrafo único).",
    ],
    tip: "Afastamento preventivo do servidor: até 60 dias, prorrogável por igual prazo, sem prejuízo da remuneração (art. 147).",
  }),

  /* ============================== LEI Nº 9.784/1999 ============================== */
  mk({
    id: "l9784-delegacao-01",
    subject: "lei9784",
    topic: "Competência, delegação e avocação",
    statement: "De acordo com a Lei nº 9.784/1999, NÃO podem ser objeto de delegação",
    options: [
      "a edição de atos de caráter normativo, a decisão de recursos administrativos e as matérias de competência exclusiva do órgão ou autoridade.",
      "a instrução de processos administrativos e a expedição de certidões.",
      "a edição de atos de caráter normativo e a instrução de processos, apenas.",
      "a decisão de recursos administrativos e a emissão de pareceres, apenas.",
      "quaisquer atos, uma vez que a competência é irrenunciável e indelegável.",
    ],
    correct: "A",
    summary:
      "A competência é irrenunciável, mas admite delegação e avocação nos casos legalmente permitidos. O art. 13 veda a delegação de três matérias: edição de atos normativos, decisão de recursos administrativos e matérias de competência exclusiva do órgão ou autoridade.",
    legalBasis: "Lei nº 9.784/1999, arts. 11 e 13",
    lawText:
      "Art. 11. A competência é irrenunciável e se exerce pelos órgãos administrativos a que foi atribuída como própria, salvo os casos de delegação e avocação legalmente admitidos.\nArt. 13. Não podem ser objeto de delegação:\nI - a edição de atos de caráter normativo;\nII - a decisão de recursos administrativos;\nIII - as matérias de competência exclusiva do órgão ou autoridade.",
    analysis: [
      "Correta. Rol completo do art. 13.",
      "Errada. Instrução de processos e expedição de certidões podem ser delegadas.",
      "Errada. A instrução é delegável, e o rol está incompleto.",
      "Errada. Pareceres são delegáveis, e o rol está incompleto.",
      "Errada. A competência é irrenunciável, mas admite delegação e avocação (arts. 11 e 12).",
    ],
    tip: "Mnemônico CE-NO-RE: Competência Exclusiva, atos NOrmativos e REcursos não se delegam.",
    difficulty: "Fácil",
  }),
  mk({
    id: "l9784-recurso-01",
    subject: "lei9784",
    topic: "Recurso administrativo e revisão",
    statement:
      "Salvo disposição legal específica, é de ..... o prazo para interposição de recurso administrativo, contado a partir da ciência ou divulgação oficial da decisão recorrida, e o recurso tramitará no máximo por ..... instâncias administrativas, salvo disposição legal diversa.\nPreenchem, correta e respectivamente, as lacunas:",
    options: ["dez dias − três", "cinco dias − duas", "quinze dias − três", "dez dias − duas", "trinta dias − quatro"],
    correct: "A",
    summary:
      "O prazo geral para interposição de recurso administrativo é de 10 dias, contados da ciência ou divulgação oficial da decisão, e o recurso tramita por no máximo 3 instâncias administrativas. O recurso é dirigido à autoridade que proferiu a decisão, que poderá reconsiderá-la em 5 dias antes de encaminhá-lo à autoridade superior.",
    legalBasis: "Lei nº 9.784/1999, arts. 56, § 1º, 57 e 59",
    lawText:
      "Art. 56, § 1º O recurso será dirigido à autoridade que proferiu a decisão, a qual, se não a reconsiderar no prazo de cinco dias, o encaminhará à autoridade superior.\nArt. 57. O recurso administrativo tramitará no máximo por três instâncias administrativas, salvo disposição legal diversa.\nArt. 59. Salvo disposição legal específica, é de dez dias o prazo para interposição de recurso administrativo, contado a partir da ciência ou divulgação oficial da decisão recorrida.",
    analysis: [
      "Correta. 10 dias para recorrer e no máximo 3 instâncias.",
      "Errada. Cinco dias é o prazo para a autoridade reconsiderar a decisão.",
      "Errada. O prazo de interposição é de 10 dias.",
      "Errada. O recurso tramita por até três instâncias.",
      "Errada. Trinta dias é o prazo para decidir o recurso (art. 59, § 1º).",
    ],
    tip: "Sequência de prazos: 10 dias para recorrer, 5 dias para reconsiderar e 30 dias para decidir (prorrogáveis por igual período, com justificativa).",
  }),
  mk({
    id: "l9784-impedimento-01",
    subject: "lei9784",
    topic: "Impedimento e suspeição",
    statement: "Nos termos da Lei nº 9.784/1999, é impedido de atuar em processo administrativo o servidor ou autoridade que",
    options: [
      "tenha amizade íntima com algum dos interessados.",
      "tenha inimizade notória com o cônjuge de algum dos interessados.",
      "esteja litigando judicial ou administrativamente com o interessado ou respectivo cônjuge ou companheiro.",
      "seja subordinado hierárquico de outro servidor que atue no processo.",
      "tenha participado de curso de capacitação sobre a matéria discutida no processo.",
    ],
    correct: "C",
    summary:
      "O impedimento traz hipóteses objetivas: interesse direto ou indireto na matéria; participação como perito, testemunha ou representante; e litígio judicial ou administrativo com o interessado ou seu cônjuge ou companheiro. A suspeição tem natureza subjetiva: amizade íntima ou inimizade notória. O servidor impedido deve comunicar o fato e abster-se de atuar; a omissão constitui falta grave.",
    legalBasis: "Lei nº 9.784/1999, arts. 18 e 20",
    lawText:
      "Art. 18. É impedido de atuar em processo administrativo o servidor ou autoridade que:\nI - tenha interesse direto ou indireto na matéria;\nII - tenha participado ou venha a participar como perito, testemunha ou representante, ou se tais situações ocorrem quanto ao cônjuge, companheiro ou parente e afins até o terceiro grau;\nIII - esteja litigando judicial ou administrativamente com o interessado ou respectivo cônjuge ou companheiro.\nArt. 20. Pode ser argüida a suspeição de autoridade ou servidor que tenha amizade íntima ou inimizade notória com algum dos interessados ou com os respectivos cônjuges, companheiros, parentes e afins até o terceiro grau.",
    analysis: [
      "Errada. Amizade íntima é hipótese de suspeição (art. 20).",
      "Errada. Inimizade notória também é hipótese de suspeição (art. 20).",
      "Correta. Litígio com o interessado ou seu cônjuge/companheiro gera impedimento (art. 18, III).",
      "Errada. A subordinação hierárquica não está prevista como impedimento.",
      "Errada. A participação em curso de capacitação não gera impedimento.",
    ],
    tip: "Impedimento = situações objetivas (dever de comunicar). Suspeição = sentimentos (amizade íntima ou inimizade notória) e pode ser arguida.",
  }),
  mk({
    id: "l9784-prioridade-01",
    subject: "lei9784",
    topic: "Prioridade de tramitação",
    statement:
      "Conforme a Lei nº 9.784/1999, terão prioridade na tramitação, em qualquer órgão ou instância, os procedimentos administrativos em que figure como parte ou interessado",
    options: [
      "pessoa com idade igual ou superior a 60 anos.",
      "pessoa com idade igual ou superior a 65 anos, apenas.",
      "servidor público estável.",
      "pessoa jurídica de direito público.",
      "pessoa com idade igual ou superior a 70 anos, exclusivamente.",
    ],
    correct: "A",
    summary:
      "O art. 69-A da Lei nº 9.784/1999 garante prioridade de tramitação aos procedimentos em que figure como parte ou interessado: pessoa com idade igual ou superior a 60 anos, pessoa com deficiência física ou mental e pessoa com doença grave (tuberculose ativa, neoplasia maligna, cardiopatia grave, entre outras).",
    legalBasis: "Lei nº 9.784/1999, art. 69-A",
    lawText:
      "Art. 69-A. Terão prioridade na tramitação, em qualquer órgão ou instância, os procedimentos administrativos em que figure como parte ou interessado:\nI - pessoa com idade igual ou superior a 60 (sessenta) anos;\nII - pessoa portadora de deficiência, física ou mental;\nIV - pessoa portadora de tuberculose ativa, esclerose múltipla, neoplasia maligna, hanseníase, paralisia irreversível e incapacitante, cardiopatia grave, doença de Parkinson, espondiloartrose anquilosante, nefropatia grave, hepatopatia grave, estados avançados da doença de Paget (osteíte deformante), contaminação por radiação, síndrome de imunodeficiência adquirida, ou outra doença grave, com base em conclusões da medicina especializada, mesmo que a doença tenha sido contraída após o início do processo.",
    analysis: [
      "Correta. Art. 69-A, I.",
      "Errada. A idade mínima é de 60 anos, e há outras hipóteses de prioridade.",
      "Errada. Não há prioridade para servidores públicos estáveis.",
      "Errada. Pessoas jurídicas de direito público não constam do rol.",
      "Errada. A idade é de 60 anos, e o rol não é exclusivo.",
    ],
    tip: "O inciso III do art. 69-A foi vetado. A FCC costuma trocar 60 por 65 ou 70 anos.",
    difficulty: "Fácil",
  }),
];
