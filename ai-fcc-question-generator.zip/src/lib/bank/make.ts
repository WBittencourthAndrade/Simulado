import type { BankQuestion, Letter } from "../types";

type Five = [string, string, string, string, string];

export function mk(p: {
  id: string;
  subject: string;
  topic: string;
  statement: string;
  options: Five;
  correct: Letter;
  summary: string;
  legalBasis: string | null;
  lawText: string | null;
  analysis: Five;
  tip: string | null;
  supportText?: string;
  difficulty?: string;
}): BankQuestion {
  return {
    id: p.id,
    subject: p.subject,
    topic: p.topic,
    supportText: p.supportText ?? null,
    statement: p.statement,
    options: { A: p.options[0], B: p.options[1], C: p.options[2], D: p.options[3], E: p.options[4] },
    correct: p.correct,
    summary: p.summary,
    legalBasis: p.legalBasis,
    lawText: p.lawText,
    analysis: { A: p.analysis[0], B: p.analysis[1], C: p.analysis[2], D: p.analysis[3], E: p.analysis[4] },
    tip: p.tip,
    difficulty: p.difficulty ?? "Média",
  };
}
