import { mk } from "./make";

export const PORTUGUES_CONSTITUCIONAL = [
  /* ============================ LÍNGUA PORTUGUESA ============================ */
  mk({
    id: "pt-crase-01",
    subject: "portugues",
    topic: "Crase",
    statement: "O sinal indicativo de crase está empregado corretamente em:",
    options: [
      "O servidor dirigiu-se à uma repartição próxima para obter a certidão.",
      "A reunião foi marcada para às 14 horas, na sala da diretoria.",
      "Os documentos foram entregues à diretora do departamento de pessoal.",
      "O candidato começou à estudar logo após a publicação do edital.",
      "Todos os funcionários assistiram à palestras sobre ética no trabalho.",
    ],
    correct: "C",
    summary:
      "A crase é a fusão da preposição \"a\" com o artigo definido feminino \"a(s)\" (ou com pronomes demonstrativos como \"aquele\", \"aquela\"). Para que ocorra, é preciso que o termo regente exija a preposição \"a\" e que o termo regido seja feminino e admita artigo. Em \"entregar algo a alguém\", o verbo pede a preposição \"a\", e \"diretora\" admite o artigo \"a\": entregues à diretora.",
    legalBasis: "Norma-padrão: emprego do acento grave (crase)",
    lawText:
      "Ocorre crase quando há fusão da preposição \"a\" com o artigo feminino \"a(s)\". Não ocorre crase: antes de palavras masculinas, de verbos, de artigo indefinido (uma), de pronomes que não admitem artigo, após outra preposição e diante de palavra no plural precedida de \"a\" no singular.",
    analysis: [
      "Errada. Não há crase antes de artigo indefinido: \"dirigiu-se a uma repartição\".",
      "Errada. A preposição \"para\" já está presente, e não se usa crase após outra preposição: \"para as 14 horas\".",
      "Correta. \"Entregar algo a alguém\" (preposição) + \"a diretora\" (artigo) = à diretora.",
      "Errada. Não ocorre crase antes de verbo: \"começou a estudar\".",
      "Errada. O \"a\" no singular diante de palavra no plural é apenas preposição: \"assistiram a palestras\" (ou \"às palestras\", se houver artigo).",
    ],
    tip: "Macete da FCC: troque a palavra feminina por uma masculina. Se aparecer \"ao\", há crase (entregues ao diretor → à diretora).",
    difficulty: "Fácil",
  }),
  mk({
    id: "pt-concordancia-01",
    subject: "portugues",
    topic: "Concordância verbal e nominal",
    statement: "A frase em que a concordância verbal está em conformidade com a norma-padrão da língua portuguesa é:",
    options: [
      "Fazem dois anos que o concurso para o tribunal foi homologado.",
      "Houveram muitas reclamações sobre o atendimento ao público.",
      "Existe, nos arquivos do setor, documentos que precisam ser digitalizados.",
      "Devem haver soluções mais eficientes para reduzir as filas.",
      "Faltam ainda três etapas para a conclusão do processo seletivo.",
    ],
    correct: "E",
    summary:
      "A FCC explora sujeito posposto e verbos impessoais. \"Haver\" (no sentido de existir/ocorrer) e \"fazer\" (indicando tempo decorrido) são impessoais: ficam na 3ª pessoa do singular e transmitem essa impessoalidade ao verbo auxiliar. Já \"existir\", \"faltar\", \"restar\" e \"bastar\" são pessoais e concordam com o sujeito, mesmo quando ele vem depois do verbo. Em \"Faltam ainda três etapas\", o sujeito posposto \"três etapas\" exige o plural.",
    legalBasis: "Norma-padrão: concordância verbal (verbos impessoais e sujeito posposto)",
    lawText:
      "Verbos impessoais (haver = existir/ocorrer; fazer = tempo decorrido) não têm sujeito e ficam na 3ª pessoa do singular, inclusive o auxiliar da locução. Verbos pessoais concordam com o sujeito, ainda que posposto.",
    analysis: [
      "Errada. \"Fazer\" indicando tempo é impessoal: \"Faz dois anos\".",
      "Errada. \"Haver\" no sentido de ocorrer é impessoal: \"Houve muitas reclamações\".",
      "Errada. \"Existir\" é pessoal e concorda com o sujeito \"documentos\": \"Existem documentos\".",
      "Errada. O auxiliar de \"haver\" impessoal também fica no singular: \"Deve haver soluções\".",
      "Correta. O sujeito posposto \"três etapas\" leva o verbo \"faltar\" ao plural.",
    ],
    tip: "Sempre que o verbo vier antes do sujeito, pergunte \"o que falta/existe/resta?\" — a resposta é o sujeito e define a concordância.",
  }),
  mk({
    id: "pt-pontuacao-01",
    subject: "portugues",
    topic: "Pontuação (emprego da vírgula)",
    statement: "Está correta a pontuação do seguinte período:",
    options: [
      "Os servidores, que participaram do treinamento receberão certificado ao final do curso.",
      "O diretor do setor de protocolo, determinou a revisão de todos os procedimentos.",
      "Quando o sistema foi atualizado, os usuários precisaram cadastrar novas senhas.",
      "Os técnicos apresentaram o relatório e, o gerente aprovou as mudanças sugeridas.",
      "A equipe, enviou ontem, os documentos solicitados pela auditoria.",
    ],
    correct: "C",
    summary:
      "Regras de ouro da vírgula cobradas pela FCC: não se separa o sujeito do predicado nem o verbo de seus complementos; a oração subordinada adverbial anteposta à principal é separada por vírgula; orações adjetivas explicativas ficam entre vírgulas. Em C, a oração adverbial temporal \"Quando o sistema foi atualizado\" está anteposta e corretamente isolada.",
    legalBasis: "Norma-padrão: emprego da vírgula",
    lawText:
      "Não se usa vírgula entre sujeito e verbo nem entre verbo e complemento. Usa-se vírgula para isolar oração adverbial anteposta, oração adjetiva explicativa (entre vírgulas) e adjuntos adverbiais deslocados (facultativa quando curtos).",
    analysis: [
      "Errada. A oração explicativa deveria estar entre duas vírgulas; com uma só vírgula, separa-se o sujeito do verbo.",
      "Errada. Há vírgula entre o sujeito (\"O diretor do setor de protocolo\") e o verbo (\"determinou\").",
      "Correta. Oração subordinada adverbial temporal anteposta separada por vírgula.",
      "Errada. A vírgula após \"e\" está mal posicionada; se usada, deveria vir antes do \"e\", pois as orações têm sujeitos diferentes.",
      "Errada. A vírgula separa o sujeito do verbo e o verbo de seu complemento.",
    ],
    tip: "Se, ao retirar o trecho entre vírgulas, a frase continuar gramatical, a pontuação tende a estar correta.",
  }),
  mk({
    id: "pt-colocacao-01",
    subject: "portugues",
    topic: "Pronomes: emprego e colocação pronominal",
    statement: "A colocação do pronome está de acordo com a norma-padrão em:",
    options: [
      "Me informaram que o prazo foi prorrogado.",
      "Não encaminhou-se o processo à chefia imediata.",
      "Nunca esqueceram-se das orientações recebidas.",
      "O servidor que se ausentou apresentou justificativa.",
      "Tudo resolveu-se após a reunião com a coordenação.",
    ],
    correct: "D",
    summary:
      "A próclise (pronome antes do verbo) é obrigatória quando há palavra atrativa: palavras negativas, advérbios sem pausa, pronomes relativos, indefinidos e demonstrativos e conjunções subordinativas. Além disso, a norma-padrão não admite iniciar oração com pronome oblíquo átono. Em D, o pronome relativo \"que\" atrai o pronome: \"que se ausentou\".",
    legalBasis: "Norma-padrão: colocação pronominal",
    lawText:
      "Próclise obrigatória diante de palavras atrativas (não, nunca, que, tudo, quem, onde, conjunções subordinativas etc.). É vedado iniciar período com pronome oblíquo átono (usa-se a ênclise: \"Informaram-me\").",
    analysis: [
      "Errada. Não se inicia oração com pronome átono: \"Informaram-me\".",
      "Errada. A palavra negativa \"Não\" exige próclise: \"Não se encaminhou\".",
      "Errada. O advérbio negativo \"Nunca\" atrai o pronome: \"Nunca se esqueceram\".",
      "Correta. O pronome relativo \"que\" torna obrigatória a próclise.",
      "Errada. O pronome indefinido \"Tudo\" atrai o pronome: \"Tudo se resolveu\".",
    ],
    tip: "Procure a palavra atrativa antes do verbo; se existir, o pronome vai para antes dele.",
    difficulty: "Fácil",
  }),
  mk({
    id: "pt-regencia-01",
    subject: "portugues",
    topic: "Regência verbal e nominal",
    statement: "A regência verbal está de acordo com a norma-padrão em:",
    options: [
      "Os candidatos assistiram o filme institucional antes da prova.",
      "O servidor visava a uma promoção na carreira.",
      "Prefiro mais trabalhar pela manhã do que à tarde.",
      "A equipe obedeceu as novas regras do setor.",
      "Os munícipes aspiram melhores condições de atendimento.",
    ],
    correct: "B",
    summary:
      "\"Visar\", no sentido de pretender ou almejar, é transitivo indireto e exige a preposição \"a\": visava a uma promoção. Os verbos assistir (ver), aspirar (almejar) e obedecer também pedem a preposição \"a\", e o verbo preferir rejeita intensificadores e a expressão \"do que\" (prefere-se uma coisa a outra).",
    legalBasis: "Norma-padrão: regência verbal",
    lawText:
      "Assistir (ver/presenciar) = TI (a); visar (almejar) = TI (a); aspirar (almejar) = TI (a); obedecer/desobedecer = TI (a); preferir = TDI (preferir algo a algo), sem \"mais\" e sem \"do que\".",
    analysis: [
      "Errada. \"Assistir\" no sentido de ver é transitivo indireto: \"assistiram ao filme\".",
      "Correta. \"Visar\" no sentido de almejar exige a preposição \"a\".",
      "Errada. \"Preferir\" não admite \"mais\" nem \"do que\": \"Prefiro trabalhar pela manhã a trabalhar à tarde\".",
      "Errada. \"Obedecer\" é transitivo indireto: \"obedeceu às novas regras\".",
      "Errada. \"Aspirar\" no sentido de almejar pede a preposição \"a\": \"aspiram a melhores condições\".",
    ],
    tip: "A FCC costuma cobrar a mudança de sentido: \"visar\" = mirar/dar visto (TD) x almejar (TI); \"aspirar\" = sorver (TD) x almejar (TI).",
  }),

  /* ========================== DIREITO CONSTITUCIONAL ========================== */
  mk({
    id: "cf-remedios-01",
    subject: "constitucional",
    topic: "Remédios constitucionais",
    statement:
      "Pedro teve negado, pelo órgão público competente, o acesso a informações relativas à sua pessoa constantes de banco de dados de entidade governamental. De acordo com a Constituição Federal, o remédio constitucional adequado para assegurar o conhecimento dessas informações é o",
    options: ["mandado de segurança.", "habeas data.", "mandado de injunção.", "habeas corpus.", "ação popular."],
    correct: "B",
    summary:
      "O habeas data é a ação constitucional destinada a assegurar o conhecimento de informações relativas à pessoa do impetrante constantes de registros ou bancos de dados de entidades governamentais ou de caráter público, bem como a retificar tais dados. Como as informações pertencem ao próprio Pedro e houve recusa administrativa, o remédio cabível é o habeas data.",
    legalBasis: "CF/1988, art. 5º, LXXII",
    lawText:
      "LXXII - conceder-se-á habeas data:\na) para assegurar o conhecimento de informações relativas à pessoa do impetrante, constantes de registros ou bancos de dados de entidades governamentais ou de caráter público;\nb) para a retificação de dados, quando não se prefira fazê-lo por processo sigiloso, judicial ou administrativo;",
    analysis: [
      "Errada. O mandado de segurança é residual: protege direito líquido e certo não amparado por habeas corpus ou habeas data (art. 5º, LXIX).",
      "Correta. Informações sobre a própria pessoa do impetrante em banco de dados governamental: habeas data (art. 5º, LXXII, a).",
      "Errada. O mandado de injunção cabe quando a falta de norma regulamentadora torna inviável o exercício de direitos constitucionais (art. 5º, LXXI).",
      "Errada. O habeas corpus protege a liberdade de locomoção (art. 5º, LXVIII).",
      "Errada. A ação popular visa anular ato lesivo ao patrimônio público, à moralidade administrativa, ao meio ambiente e ao patrimônio histórico e cultural (art. 5º, LXXIII).",
    ],
    tip: "Súmula 2 do STJ: não cabe habeas data se não houve recusa de informações pela autoridade administrativa. Informação de terceiros ou de interesse coletivo → mandado de segurança.",
    difficulty: "Fácil",
  }),
  mk({
    id: "cf-adm-concurso-01",
    subject: "constitucional",
    topic: "Administração Pública (arts. 37 a 41)",
    statement: "Nos termos da Constituição Federal, o prazo de validade do concurso público será de",
    options: [
      "até dois anos, prorrogável uma vez, por igual período.",
      "dois anos, improrrogável.",
      "até quatro anos, prorrogável uma vez, por igual período.",
      "até dois anos, prorrogável sucessivas vezes, a critério da Administração.",
      "um ano, prorrogável uma vez, por até dois anos.",
    ],
    correct: "A",
    summary:
      "A Constituição fixa o prazo de validade do concurso em até dois anos, podendo ser prorrogado uma única vez, por período igual ao inicialmente fixado. Assim, um concurso com validade de 1 ano só pode ser prorrogado por mais 1 ano. A FCC costuma trocar \"até dois anos\" por \"dois anos\" ou alterar o número de prorrogações.",
    legalBasis: "CF/1988, art. 37, III e IV",
    lawText:
      "III - o prazo de validade do concurso público será de até dois anos, prorrogável uma vez, por igual período;\nIV - durante o prazo improrrogável previsto no edital de convocação, aquele aprovado em concurso público de provas ou de provas e títulos será convocado com prioridade sobre novos concursados para assumir cargo ou emprego, na carreira;",
    analysis: [
      "Correta. Reprodução literal do art. 37, III.",
      "Errada. O prazo é de \"até\" dois anos e admite uma prorrogação.",
      "Errada. O prazo inicial máximo é de dois anos, não quatro.",
      "Errada. Admite-se uma única prorrogação.",
      "Errada. A prorrogação deve ser por período igual ao inicialmente fixado.",
    ],
    tip: "Guarde a tríade da FCC: \"até dois anos\" + \"uma vez\" + \"igual período\".",
    difficulty: "Fácil",
  }),
  mk({
    id: "cf-politicos-01",
    subject: "constitucional",
    topic: "Direitos políticos e nacionalidade",
    statement: "De acordo com a Constituição Federal, o alistamento eleitoral e o voto são facultativos para",
    options: [
      "os maiores de dezesseis e menores de dezoito anos, os analfabetos e os maiores de setenta anos.",
      "os maiores de dezoito e menores de vinte e um anos, os analfabetos e os maiores de sessenta anos.",
      "os conscritos, durante o período do serviço militar obrigatório, e os analfabetos.",
      "os estrangeiros residentes no País há mais de quinze anos e os maiores de setenta anos.",
      "os maiores de sessenta e cinco anos e as pessoas com deficiência.",
    ],
    correct: "A",
    summary:
      "O voto é obrigatório para os maiores de 18 anos e facultativo para três grupos: analfabetos, maiores de 70 anos e maiores de 16 e menores de 18 anos. Estrangeiros e conscritos (durante o serviço militar obrigatório) sequer podem alistar-se como eleitores.",
    legalBasis: "CF/1988, art. 14, §§ 1º e 2º",
    lawText:
      "§ 1º O alistamento eleitoral e o voto são:\nI - obrigatórios para os maiores de dezoito anos;\nII - facultativos para:\na) os analfabetos;\nb) os maiores de setenta anos;\nc) os maiores de dezesseis e menores de dezoito anos.\n§ 2º Não podem alistar-se como eleitores os estrangeiros e, durante o período do serviço militar obrigatório, os conscritos.",
    analysis: [
      "Correta. Corresponde exatamente ao art. 14, § 1º, II.",
      "Errada. As faixas etárias estão incorretas (16 a 18 anos e mais de 70 anos).",
      "Errada. Os conscritos não podem alistar-se durante o serviço militar obrigatório (art. 14, § 2º).",
      "Errada. Estrangeiros não podem alistar-se como eleitores.",
      "Errada. Não há previsão constitucional de voto facultativo para esses grupos.",
    ],
    tip: "Mnemônico dos 3 \"As\": Analfabetos, Adolescentes (16 e 17 anos) e Anciãos (mais de 70).",
    difficulty: "Fácil",
  }),
  mk({
    id: "cf-nacionalidade-01",
    subject: "constitucional",
    topic: "Direitos políticos e nacionalidade",
    statement: "Segundo a Constituição Federal, é cargo privativo de brasileiro nato o de",
    options: [
      "Ministro do Superior Tribunal de Justiça.",
      "Senador da República.",
      "Ministro de Estado da Defesa.",
      "Governador de Estado.",
      "Ministro de Estado da Justiça e Segurança Pública.",
    ],
    correct: "C",
    summary:
      "A Constituição enumera taxativamente os cargos privativos de brasileiro nato, ligados à linha sucessória da Presidência e à segurança nacional. Entre os Ministros de Estado, apenas o da Defesa consta do rol. Ministros do STJ, Senadores e Governadores podem ser brasileiros naturalizados.",
    legalBasis: "CF/1988, art. 12, § 3º",
    lawText:
      "§ 3º São privativos de brasileiro nato os cargos:\nI - de Presidente e Vice-Presidente da República;\nII - de Presidente da Câmara dos Deputados;\nIII - de Presidente do Senado Federal;\nIV - de Ministro do Supremo Tribunal Federal;\nV - da carreira diplomática;\nVI - de oficial das Forças Armadas;\nVII - de Ministro de Estado da Defesa.",
    analysis: [
      "Errada. Apenas os Ministros do STF devem ser natos; os do STJ, não.",
      "Errada. O Senador pode ser naturalizado; só o Presidente do Senado precisa ser nato.",
      "Correta. Ministro de Estado da Defesa (art. 12, § 3º, VII).",
      "Errada. O cargo de Governador não consta do rol taxativo.",
      "Errada. Entre os Ministros de Estado, somente o da Defesa é privativo de nato.",
    ],
    tip: "Mnemônico MP3.COM: Ministro do STF, Presidente e Vice, Presidentes da Câmara e do Senado, Carreira diplomática, Oficial das Forças Armadas e Ministro da Defesa.",
  }),
  mk({
    id: "cf-art5-domicilio-01",
    subject: "constitucional",
    topic: "Direitos e garantias fundamentais (art. 5º)",
    statement:
      "Considere as seguintes situações hipotéticas, à luz do art. 5º da Constituição Federal:\nI. Durante a noite, policiais ingressam em residência, sem consentimento do morador, para prestar socorro a vítima de acidente doméstico.\nII. Durante a noite, oficial de justiça ingressa em residência, sem consentimento do morador, para cumprir mandado judicial de busca e apreensão.\nIII. Durante o dia, policiais ingressam em residência, sem consentimento do morador, em razão de flagrante delito.\nEstá em conformidade com a Constituição Federal o que consta em",
    options: ["I, apenas.", "I e III, apenas.", "II e III, apenas.", "III, apenas.", "I, II e III."],
    correct: "B",
    summary:
      "A casa é asilo inviolável. Sem o consentimento do morador, só se pode ingressar: a qualquer hora, em caso de flagrante delito, desastre ou para prestar socorro; e, apenas durante o dia, por determinação judicial. Assim, as situações I (socorro) e III (flagrante) são válidas, mas a II é inconstitucional, pois o mandado judicial só pode ser cumprido durante o dia.",
    legalBasis: "CF/1988, art. 5º, XI",
    lawText:
      "XI - a casa é asilo inviolável do indivíduo, ninguém nela podendo penetrar sem consentimento do morador, salvo em caso de flagrante delito ou desastre, ou para prestar socorro, ou, durante o dia, por determinação judicial;",
    analysis: [
      "Errada. Está incompleta: a situação III também é válida.",
      "Correta. Socorro (I) e flagrante (III) autorizam o ingresso a qualquer hora.",
      "Errada. A situação II é inconstitucional, pois a ordem judicial só se cumpre durante o dia.",
      "Errada. Está incompleta: a situação I também é válida.",
      "Errada. A situação II viola o art. 5º, XI.",
    ],
    tip: "Pegadinha clássica da FCC: a restrição \"durante o dia\" vale somente para a determinação judicial.",
  }),
];
