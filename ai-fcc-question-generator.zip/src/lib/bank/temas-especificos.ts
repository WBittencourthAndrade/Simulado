import { mk } from "./make";

export const TEMAS_ESPECIFICOS = [
  /* ======================= CRASE (FOCO 100%) ======================= */
  mk({
    id: "pt-crase-02",
    subject: "portugues",
    topic: "Crase: casos proibidos, facultativos e obrigatórios",
    statement:
      "Considere as frases abaixo:\nI. Os relatórios foram encaminhados à Vossa Senhoria para análise e parecer.\nII. À medida que os candidatos chegavam ao local de prova, os fiscais conferiam os documentos.\nIII. O atendimento presencial funciona de segunda à sexta-feira, das 9h às 17h.\nO sinal indicativo de crase está empregado em conformidade com a norma-padrão APENAS em",
    options: ["I.", "II.", "III.", "I e II.", "II e III."],
    correct: "B",
    summary:
      "Na locução conjuntiva proporcional feminina “À medida que”, o emprego do acento indicativo de crase é obrigatório, assim como na indicação exata de horas (“às 17h”). Já antes de pronomes de tratamento (“Vossa Senhoria”) e entre expressões do tipo “de segunda a sexta-feira” (precedidas da preposição “de”, sem artigo), não ocorre crase.",
    legalBasis: "Norma-padrão: emprego do acento grave (crase em locuções e casos proibidos)",
    lawText:
      "Usa-se obrigatoriamente o acento grave nas locuções adverbiais, prepositivas e conjuntivas femininas (à medida que, às pressas, à espera de). Não ocorre crase diante de pronomes de tratamento (salvo senhora/senhorita) nem em expressões introduzidas por 'de ... a ...' sem artigo.",
    analysis: [
      "Errada. Em I, não ocorre crase antes do pronome de tratamento 'Vossa Senhoria'.",
      "Correta. Apenas o item II está inteiramente correto ('À medida que').",
      "Errada. Em III, 'de segunda a sexta-feira' não leva crase (há apenas preposição 'a' em correlação com 'de').",
      "Errada. O item I está incorreto.",
      "Errada. O item III apresenta crase indevida em 'à sexta-feira'.",
    ],
    tip: "Correlação 'de ... a ...' (de segunda a sexta) = sem crase; correlação 'da ... à ...' (da segunda à sexta) = com crase.",
  }),
  mk({
    id: "pt-crase-03",
    subject: "portugues",
    topic: "Crase: emprego facultativo e pronomes demonstrativos",
    statement:
      "A substituição do elemento sublinhado pelo que se encontra entre parênteses torna obrigatório o emprego do sinal indicativo de crase em:",
    options: [
      "O coordenador elogiou a dedicação da equipe. (aquela equipe)",
      "A servidora dedicou-se a elaborar o parecer técnico. (a revisão do processo)",
      "Os documentos pertenciam a nossa seção. (sua seção)",
      "O palestrante referiu-se a questões relevantes. (algumas questões)",
      "Entregamos o requerimento a ela ainda pela manhã. (Vossa Excelência)",
    ],
    correct: "B",
    summary:
      "Em 'dedicou-se a elaborar', não há crase porque 'elaborar' é verbo. Ao substituir por 'a revisão do processo', o verbo 'dedicar-se' exige a preposição 'a' e o substantivo feminino 'revisão' vem determinado pelo artigo 'a', tornando obrigatória a crase: dedicou-se à revisão do processo.",
    legalBasis: "Norma-padrão: regência e fusão da preposição 'a' com o artigo feminino 'a'",
    lawText:
      "Quando o termo regente exige a preposição 'a' (dedicar-se a) e o termo regido é substantivo feminino determinado por artigo definido ('a revisão'), ocorre crase obrigatória ('à revisão'). Diante de verbo, pronome indefinido ou pronome de tratamento, a crase é proibida; diante de pronome possessivo feminino singular, é facultativa.",
    analysis: [
      "Errada. 'Elogiar' é transitivo direto (não pede preposição 'a'), logo 'elogiou aquela equipe' não tem crase.",
      "Correta. 'Dedicar-se a' + 'a revisão do processo' = dedicou-se à revisão do processo.",
      "Errada. Diante de pronome possessivo feminino singular ('sua seção'), a crase é facultativa, e não obrigatória.",
      "Errada. Diante do pronome indefinido 'algumas', não ocorre crase.",
      "Errada. Diante de pronome de tratamento ('Vossa Excelência'), não ocorre crase.",
    ],
    tip: "Cuidado com 'aquele/aquela': só leva crase se o verbo exigir a preposição 'a' (ex.: referiu-se àquela equipe).",
  }),

  /* ======================= CONCORDÂNCIA (FOCO 100%) ======================= */
  mk({
    id: "pt-concordancia-02",
    subject: "portugues",
    topic: "Concordância verbal e nominal",
    statement:
      "As normas de concordância verbal e nominal estão inteiramente respeitadas em:",
    options: [
      "Seguem anexo ao processo os comprovantes solicitados pela diretoria.",
      "Tratam-se de medidas indispensáveis ao bom funcionamento do setor.",
      "Já haviam sido protocolados todos os requerimentos referentes ao certame.",
      "É necessário muita cautela na conferência dos dados cadastrais.",
      "Bastam uma única assinatura da chefia para validar o formulário.",
    ],
    correct: "C",
    summary:
      "Em 'Já haviam sido protocolados todos os requerimentos', o verbo 'haver' é auxiliar da locução passiva (equivalente a 'tinham sido protocolados') e, por isso, concorda normalmente no plural com o sujeito paciente 'todos os requerimentos'. Já 'anexo' concorda com o substantivo ('Seguem anexos os comprovantes'), e 'Trata-se de' fica no singular por ter índice de indeterminação do sujeito.",
    legalBasis: "Norma-padrão: concordância verbal (voz passiva e verbo haver auxiliar) e nominal",
    lawText:
      "O verbo 'haver', quando empregado como auxiliar nos tempos compostos (equivalente a 'ter'), é pessoal e concorda com o sujeito. 'Trata-se de' (VTI + se) permanece na 3ª pessoa do singular. O adjetivo 'anexo' concorda em gênero e número com o substantivo a que se refere.",
    analysis: [
      "Errada. O adjetivo deve concordar com 'os comprovantes': 'Seguem anexos'.",
      "Errada. Com verbo transitivo indireto + 'se' (índice de indeterminação), o verbo fica no singular: 'Trata-se de medidas'.",
      "Correta. Sujeito paciente 'todos os requerimentos' no plural → 'Já haviam sido protocolados'.",
      "Errada. Na ausência de artigo antes de 'muita cautela', 'necessário' é invariável, mas 'cautela' determinada por 'muita' exige na norma culta 'É necessária muita cautela' ou 'É necessário cautela'.",
      "Errada. O sujeito é singular ('uma única assinatura'), logo o verbo deve ficar no singular: 'Basta uma única assinatura'.",
    ],
    tip: "Pegadinha da FCC: 'Havia muitos processos' (existir = singular) x 'Haviam sido arquivados muitos processos' (auxiliar = plural).",
  }),

  /* ======================= ATOS ADMINISTRATIVOS (FOCO 100%) ======================= */
  mk({
    id: "adm-atos-02",
    subject: "administrativo",
    topic: "Atos administrativos: atributos, elementos e extinção",
    statement:
      "Considere os seguintes elementos e atributos do ato administrativo:\nI. Atributo pelo qual o ato administrativo pode ser posto em execução pela própria Administração Pública, sem necessidade de prévia intervenção do Poder Judiciário.\nII. Elemento sempre vinculado do ato administrativo que corresponde ao efeito jurídico imediato que o ato produz.\nIII. Extinção do ato administrativo válido, mas que deixou de ser conveniente ou oportuno ao interesse público, operando efeitos a partir de então (ex nunc).\nOs itens I, II e III correspondem, correta e respectivamente, a:",
    options: [
      "imperatividade − objeto − anulação.",
      "autoexecutoriedade − finalidade − revogação.",
      "autoexecutoriedade − objeto − revogação.",
      "presunção de legitimidade − motivo − cassação.",
      "tipicidade − finalidade − anulação.",
    ],
    correct: "B",
    summary:
      "A autoexecutoriedade permite à Administração executar diretamente suas decisões pelos próprios meios, sem prévia ordem judicial, quando previsto em lei ou em medidas urgentes. A finalidade é o elemento sempre vinculado que busca o interesse público e o resultado previsto em lei (o efeito jurídico imediato variável nos discricionários é o objeto). A revogação retira ato válido por mérito (conveniência e oportunidade) com efeitos ex nunc.",
    legalBasis: "Lei nº 9.784/1999, art. 53; Lei nº 4.717/1965, art. 2º",
    lawText:
      "São requisitos/elementos do ato administrativo: competência, finalidade, forma (vinculados), motivo e objeto (podem ser discricionários). São atributos: presunção de legitimidade e veracidade, autoexecutoriedade, tipicidade e imperatividade (PATI).",
    analysis: [
      "Errada. O item I descreve a autoexecutoriedade, e o item III descreve a revogação.",
      "Correta. I = autoexecutoriedade; II = finalidade (sempre vinculada); III = revogação (ex nunc).",
      "Errada. O objeto pode ser discricionário; o elemento sempre vinculado voltado ao fim legal é a finalidade.",
      "Errada. Os três conceitos estão incorretos.",
      "Errada. Tipicidade é o atributo pelo qual o ato deve corresponder a figuras definidas em lei, e anulação decorre de ilegalidade.",
    ],
    tip: "Elementos sempre vinculados: CO-FI-FO (Competência, Finalidade e Forma). Mérito administrativo: MO-OB (Motivo e Objeto).",
  }),
  mk({
    id: "adm-atos-03",
    subject: "administrativo",
    topic: "Atos administrativos: convalidação e decadência (Lei nº 9.784/1999)",
    statement:
      "Nos termos do art. 55 da Lei nº 9.784/1999, em decisão na qual se evidencie não acarretarem lesão ao interesse público nem prejuízo a terceiros, os atos administrativos que apresentarem defeitos sanáveis",
    options: [
      "deverão ser revogados pela autoridade superior, com efeitos retroativos.",
      "poderão ser convalidados pela própria Administração.",
      "somente poderão ser convalidados pelo Poder Judiciário, mediante provocação.",
      "são nulos de pleno direito e insuscetíveis de correção a qualquer tempo.",
      "convalidam-se automaticamente após o prazo de dois anos de sua publicação.",
    ],
    correct: "B",
    summary:
      "A convalidação é o suprimento de vícios sanáveis do ato administrativo (tipicamente vícios de competência, desde que não exclusiva, e de forma, desde que não essencial), com efeitos retroativos à data em que o ato foi praticado. Segundo o art. 55 da Lei nº 9.784/1999, exige-se que não haja lesão ao interesse público nem prejuízo a terceiros.",
    legalBasis: "Lei nº 9.784/1999, art. 55",
    lawText:
      "Art. 55. Em decisão na qual se evidencie não acarretarem lesão ao interesse público nem prejuízo a terceiros, os atos que apresentarem defeitos sanáveis poderão ser convalidados pela própria Administração.",
    analysis: [
      "Errada. A revogação incide sobre atos válidos por razões de mérito e tem efeitos ex nunc.",
      "Correta. Reprodução literal do art. 55 da Lei nº 9.784/1999.",
      "Errada. A convalidação é realizada pela própria Administração.",
      "Errada. Defeitos sanáveis admitem convalidação.",
      "Errada. O prazo decadencial para anular atos favoráveis é de 5 anos (art. 54), não de 2 anos.",
    ],
    tip: "Vícios sanáveis (admitem convalidação): FOCO — Forma (não essencial) e Competência (não exclusiva).",
  }),

  /* ======================= LICITAÇÕES LEI 14.133/2021 (FOCO 100%) ======================= */
  mk({
    id: "adm-licitacoes-01",
    subject: "administrativo",
    topic: "Licitações e contratos (Lei nº 14.133/2021)",
    statement:
      "De acordo com a Lei nº 14.133/2021 (Nova Lei de Licitações e Contratos Administrativos), são modalidades de licitação:",
    options: [
      "pregão, concorrência, tomada de preços, convite e leilão.",
      "pregão, concorrência, concurso, leilão e diálogo competitivo.",
      "concorrência, tomada de preços, convite, concurso e consulta.",
      "pregão, concorrência, leilão, diálogo competitivo e regime diferenciado de contratações.",
      "pregão, concurso, leilão, convite e diálogo competitivo.",
    ],
    correct: "B",
    summary:
      "O art. 28 da Lei nº 14.133/2021 estabelece cinco modalidades de licitação: pregão, concorrência, concurso, leilão e diálogo competitivo. Foram extintas as antigas modalidades tomada de preços e convite (bem como o RDC), sendo expressamente vedada a criação de outras modalidades ou a combinação entre elas.",
    legalBasis: "Lei nº 14.133/2021, art. 28",
    lawText:
      "Art. 28. São modalidades de licitação:\nI - pregão;\nII - concorrência;\nIII - concurso;\nIV - leilão;\nV - diálogo competitivo.\n§ 2º É vedada a criação de outras modalidades de licitação ou, ainda, a combinação daquelas referidas no caput deste artigo.",
    analysis: [
      "Errada. Tomada de preços e convite deixaram de existir na Lei nº 14.133/2021.",
      "Correta. Literalidade do art. 28, I a V, da Lei nº 14.133/2021.",
      "Errada. Tomada de preços e convite foram extintos, e consulta não consta do art. 28.",
      "Errada. O RDC não é modalidade da Lei nº 14.133/2021, e faltou o concurso.",
      "Errada. O convite foi extinto, e faltou a concorrência.",
    ],
    tip: "Na Lei 14.133/2021 saíram Tomada de Preços e Convite e entrou o Diálogo Competitivo.",
    difficulty: "Fácil",
  }),
  mk({
    id: "adm-licitacoes-02",
    subject: "administrativo",
    topic: "Licitações e contratos (Lei nº 14.133/2021)",
    statement:
      "A Administração Pública pretende contratar profissional do setor artístico, consagrado pela crítica especializada, por meio de empresário exclusivo, para apresentação em evento cultural oficial. Nos termos da Lei nº 14.133/2021, essa contratação",
    options: [
      "deve ser precedida de licitação na modalidade concurso.",
      "configura hipótese de dispensa de licitação em razão do valor.",
      "configura hipótese de inexigibilidade de licitação, por inviabilidade de competição.",
      "é vedada quando realizada por intermédio de empresário exclusivo.",
      "configura hipótese de licitação dispensada, exclusiva para bens móveis.",
    ],
    correct: "C",
    summary:
      "A contratação de profissional do setor artístico, diretamente ou por meio de empresário exclusivo, desde que consagrado pela crítica especializada ou pela opinião pública, constitui hipótese clássica de inexigibilidade de licitação, prevista no art. 74, II, da Lei nº 14.133/2021, diante da inviabilidade de competição.",
    legalBasis: "Lei nº 14.133/2021, art. 74, II e § 2º",
    lawText:
      "Art. 74. É inexigível a licitação quando inviável a competição, em especial nos casos de:\nII - contratação de profissional do setor artístico, diretamente ou por meio de empresário exclusivo, desde que consagrado pela crítica especializada ou pela opinião pública;\n§ 2º Para fins do disposto no inciso II do caput deste artigo, considera-se empresário exclusivo a pessoa física ou jurídica que possua contrato, declaração, carta ou outro documento que ateste a exclusividade permanente e contínua de representação, no País ou em Estado específico, do profissional do setor artístico, afastada a possibilidade de contratação direta por inexigibilidade por meio de empresário com representação restrita a evento ou local específico.",
    analysis: [
      "Errada. Concurso é modalidade para escolha de trabalho técnico, científico ou artístico mediante prêmio ou remuneração aos vencedores.",
      "Errada. Trata-se de inexigibilidade (art. 74, II), e não de dispensa (art. 75).",
      "Correta. Art. 74, II, da Lei nº 14.133/2021.",
      "Errada. A lei admite a contratação diretamente ou por meio de empresário exclusivo (com exclusividade permanente e contínua).",
      "Errada. Licitação dispensada (alienação de bens, art. 76) não se confunde com inexigibilidade.",
    ],
    tip: "Artista consagrado = INEXIGIBILIDADE (art. 74, II), mas a exclusividade do empresário não pode ser restrita apenas ao dia/evento específico (§ 2º).",
  }),

  /* ======================= ARQUIVOLOGIA (FOCO 100%) ======================= */
  mk({
    id: "arq-tres-idades-01",
    subject: "arquivologia",
    topic: "Teoria das três idades (ciclo vital dos documentos)",
    statement:
      "De acordo com a Lei nº 8.159/1991 e a teoria das três idades (ciclo vital dos documentos), os documentos que, não sendo de uso corrente nos órgãos produtores, por razões de interesse administrativo, aguardam a sua eliminação ou recolhimento para guarda permanente são denominados documentos",
    options: ["correntes.", "intermediários.", "permanentes.", "setoriais.", "históricos."],
    correct: "B",
    summary:
      "Pela teoria das três idades (adotada pelo art. 8º da Lei nº 8.159/1991), o ciclo vital dos documentos compreende três fases: corrente (1ª idade — documentos em curso ou de consulta frequente), intermediária (2ª idade — documentos que deixaram de ser de uso corrente, mas ainda possuem valor primário/administrativo e aguardam eliminação ou recolhimento) e permanente (3ª idade — documentos de valor histórico, probatório e informativo, que são inalienáveis e imprescritíveis).",
    legalBasis: "Lei nº 8.159/1991, arts. 8º e 10",
    lawText:
      "Art. 8º Os documentos públicos são identificados como correntes, intermediários e permanentes.\n§ 1º Consideram-se documentos correntes aqueles em curso ou que, mesmo sem movimentação, constituam objeto de consultas freqüentes.\n§ 2º Consideram-se documentos intermediários aqueles que, não sendo de uso corrente nos órgãos produtores, por razões de interesse administrativo, aguardam a sua eliminação ou recolhimento para guarda permanente.\n§ 3º Consideram-se documentos permanentes os conjuntos de documentos de valor histórico, probatório e informativo que devem ser definitivamente preservados.\nArt. 10. Os documentos de valor permanente são inalienáveis e imprescritíveis.",
    analysis: [
      "Errada. Documentos correntes são aqueles em curso ou de consulta frequente (§ 1º).",
      "Correta. Reprodução literal do art. 8º, § 2º, da Lei nº 8.159/1991.",
      "Errada. Documentos permanentes possuem valor histórico, probatório e informativo e jamais são eliminados (§ 3º).",
      "Errada. 'Setorial' refere-se à localização física de arquivos correntes, e não à fase do ciclo vital.",
      "Errada. Documentos históricos pertencem à fase permanente.",
    ],
    tip: "Passagem do corrente para o intermediário = TRANSFERÊNCIA; entrada no arquivo permanente = RECOLHIMENTO.",
    difficulty: "Fácil",
  }),
  mk({
    id: "arq-gestao-02",
    subject: "arquivologia",
    topic: "Gestão de documentos, classificação e tabela de temporalidade",
    statement:
      "Na gestão de documentos, o instrumento arquivístico resultante da avaliação documental que define os prazos de guarda dos documentos nas fases corrente e intermediária e determina a sua destinação final (eliminação ou recolhimento para guarda permanente) é",
    options: [
      "o protocolo de expedição.",
      "o quadro de arranjo.",
      "a tabela de temporalidade.",
      "o guia do arquivo permanente.",
      "o índice onomástico.",
    ],
    correct: "C",
    summary:
      "A tabela de temporalidade é o instrumento de gestão aprovado por autoridade competente que regula o ciclo vital dos documentos: fixa os prazos de retenção nas fases corrente (1ª idade) e intermediária (2ª idade) e estabelece a destinação final — eliminação (quando esgotado o valor primário e ausente valor secundário) ou recolhimento ao arquivo permanente.",
    legalBasis: "Lei nº 8.159/1991, arts. 3º e 9º; Dicionário Brasileiro de Terminologia Arquivística",
    lawText:
      "Art. 3º Considera-se gestão de documentos o conjunto de procedimentos e operações técnicas referentes à sua produção, tramitação, uso, avaliação e arquivamento em fase corrente e intermediária, visando a sua eliminação ou recolhimento para guarda permanente.\nArt. 9º A eliminação de documentos produzidos por instituições públicas e de caráter público será realizada mediante autorização da instituição arquivística pública, na sua específica esfera de competência.",
    analysis: [
      "Errada. O protocolo controla o recebimento, registro, autuação e tramitação de documentos correntes.",
      "Errada. O quadro de arranjo é utilizado na organização de fundos em arquivos permanentes.",
      "Correta. A tabela de temporalidade fixa os prazos de guarda e a destinação final.",
      "Errada. O guia é instrumento de pesquisa destinado a orientar usuários sobre o acervo de um arquivo permanente.",
      "Errada. O índice onomástico apenas lista nomes de pessoas para localização de documentos.",
    ],
    tip: "Plano de classificação responde 'onde arquivar por função/assunto'; Tabela de temporalidade responde 'por quanto tempo guardar e qual o destino final'.",
  }),

  /* =================== DIREITO PENAL: CRIMES CONTRA A ADMINISTRAÇÃO PÚBLICA =================== */
  mk({
    id: "pen-crimes-adm-01",
    subject: "penal",
    topic: "Crimes contra a Administração Pública",
    statement:
      "Mário, servidor público, deixou de praticar, indevidamente, ato de ofício que lhe competia, apenas para satisfazer sentimento pessoal de antipatia que nutria contra um cidadão que aguardava atendimento. Já Lúcia, também servidora pública, exigiu para si, em razão da função que exercia, vantagem indevida de um contribuinte. De acordo com o Código Penal, Mário e Lúcia praticaram, respectivamente, os crimes de",
    options: [
      "corrupção passiva privilegiada e corrupção passiva.",
      "prevaricação e concussão.",
      "condescendência criminosa e peculato.",
      "prevaricação e corrupção passiva.",
      "advocacia administrativa e concussão.",
    ],
    correct: "B",
    summary:
      "Retardar ou deixar de praticar ato de ofício indevidamente, ou praticá-lo contra disposição expressa de lei, para satisfazer interesse ou sentimento pessoal configura prevaricação (art. 319 do CP). Já exigir, para si ou para outrem, direta ou indiretamente, em razão da função, vantagem indevida caracteriza o crime de concussão (art. 316 do CP).",
    legalBasis: "Código Penal (Decreto-Lei nº 2.848/1940), arts. 316 e 319",
    lawText:
      "Art. 316. Exigir, para si ou para outrem, direta ou indiretamente, ainda que fora da função ou antes de assumi-la, mas em razão dela, vantagem indevida: Pena - reclusão, de 2 (dois) a 12 (doze) anos, e multa.\nArt. 319. Retardar ou deixar de praticar, indevidamente, ato de ofício, ou praticá-lo contra disposição expressa de lei, para satisfazer interesse ou sentimento pessoal: Pena - detenção, de três meses a um ano, e multa.",
    analysis: [
      "Errada. Na corrupção passiva privilegiada (art. 317, § 2º), o servidor cede a pedido ou influência de outrem; na corrupção passiva (art. 317), o verbo é solicitar, receber ou aceitar promessa.",
      "Correta. Interesse ou sentimento pessoal = prevaricação (art. 319); exigir vantagem indevida = concussão (art. 316).",
      "Errada. Condescendência criminosa é deixar, por indulgência, de responsabilizar subordinado (art. 320).",
      "Errada. O verbo 'exigir' caracteriza concussão, e não corrupção passiva.",
      "Errada. Advocacia administrativa consiste em patrocinar interesse privado perante a administração (art. 321).",
    ],
    tip: "Verbos nucleares favoritos da FCC: EXIGIR = Concussão; SOLICITAR/RECEBER/ACEITAR = Corrupção passiva; OFERECER/PROMETER = Corrupção ativa.",
  }),
  mk({
    id: "pen-crimes-adm-02",
    subject: "penal",
    topic: "Crimes contra a Administração Pública",
    statement:
      "Tício, servidor público, por negligência no fechamento do almoxarifado da repartição, concorreu culposamente para que um terceiro subtraísse equipamentos públicos. Antes de proferida sentença irrecorrível no processo criminal, Tício reparou integralmente o dano causado ao erário. Nos termos do art. 312, § 3º, do Código Penal, a reparação do dano, nesse caso,",
    options: [
      "reduz de um a dois terços a pena imposta.",
      "extingue a punibilidade.",
      "reduz de metade a pena imposta.",
      "não interfere na punibilidade, configurando apenas circunstância atenuante genérica.",
      "substitui a pena privativa de liberdade por multa.",
    ],
    correct: "B",
    summary:
      "Quando o funcionário concorre culposamente para o crime de outrem, responde por peculato culposo (art. 312, § 2º, do CP). Conforme o § 3º do art. 312, no peculato culposo, se a reparação do dano precede a sentença irrecorrível, extingue a punibilidade; se lhe é posterior, reduz de metade a pena imposta.",
    legalBasis: "Código Penal (Decreto-Lei nº 2.848/1940), art. 312, §§ 2º e 3º",
    lawText:
      "Art. 312, § 2º Se o funcionário concorre culposamente para o crime de outrem: Pena - detenção, de três meses a um ano.\n§ 3º No caso do parágrafo anterior, a reparação do dano, se precede à sentença irrecorrível, extingue a punibilidade; se lhe é posterior, reduz de metade a pena imposta.",
    analysis: [
      "Errada. A redução de 1 a 2/3 refere-se ao arrependimento posterior geral (art. 16 do CP), mas o peculato culposo tem regra especial mais benéfica.",
      "Correta. No peculato culposo, a reparação antes da sentença irrecorrível extingue a punibilidade (art. 312, § 3º, 1ª parte).",
      "Errada. A redução de metade ocorre quando a reparação é posterior à sentença irrecorrível.",
      "Errada. Há previsão expressa de extinção da punibilidade para o peculato culposo.",
      "Errada. O efeito legal é a extinção da punibilidade.",
    ],
    tip: "Só no peculato CULPOSO a reparação antes do trânsito em julgado extingue a punibilidade; no peculato doloso, não extingue!",
  }),
];
