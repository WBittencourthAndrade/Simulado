import { and, eq, isNotNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { questions, quizzes } from "@/db/schema";
import { chatJSON, freeAiEnabled, getProvider, type ProviderInfo } from "./ai";
import { bankFor } from "./bank";
import { isStrictBankMatch, resolveFocus, type LegalReferenceNote } from "./focus";
import { HttpError } from "./http";
import { lawUrlFor } from "./laws";
import { GENERATION_SYSTEM, generationPrompt } from "./prompts";
import { matchSubject } from "./subjects";
import { clip, shuffle, similarity } from "./text";
import { LETTERS, isLetter, type BankQuestion, type GeneratedQuestion, type Letter, type Options, type PlanItem } from "./types";

type QuizRow = typeof quizzes.$inferSelect;
type NewQuestion = typeof questions.$inferInsert;

export function batchConfig(): { batchSize: number; concurrency: number } {
  return getProvider().premium ? { batchSize: 3, concurrency: 3 } : { batchSize: 1, concurrency: 1 };
}

/** Remove marcações markdown que alguns modelos inserem (negrito, títulos, crases). */
const cleanMd = (s: string): string =>
  s
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/__(.+?)__/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/^#{1,6}\s+/gm, "")
    .trim();
const str = (v: unknown): string => (typeof v === "string" ? cleanMd(v) : typeof v === "number" ? String(v) : "");
const stripLetterPrefix = (s: string): string => s.replace(/^\(?[A-Ea-e]\s*[).:\-–]\s+/, "").trim();

/** Valida e normaliza uma questão vinda da IA. Retorna null se estiver incompleta. */
export function normalizeQuestion(raw: unknown, fallbackTopic: string): GeneratedQuestion | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const statement = str(r.statement ?? r.enunciado ?? r.question);
  if (statement.length < 15) return null;

  const options: Partial<Options> = {};
  const ro = r.options ?? r.alternatives ?? r.alternativas;
  if (Array.isArray(ro)) {
    ro.slice(0, 5).forEach((o, i) => {
      const text = typeof o === "string" ? o : str((o as Record<string, unknown>)?.text);
      options[LETTERS[i]] = stripLetterPrefix(text);
    });
  } else if (ro && typeof ro === "object") {
    const obj = ro as Record<string, unknown>;
    for (const L of LETTERS) options[L] = stripLetterPrefix(str(obj[L] ?? obj[L.toLowerCase()]));
  }
  if (!LETTERS.every((L) => (options[L] ?? "").length > 0)) return null;

  const cRaw = str(r.correct ?? r.answer ?? r.gabarito).toUpperCase();
  const m = cRaw.match(/\b([A-E])\b/) ?? cRaw.match(/([A-E])/);
  const correct = m?.[1];
  if (!isLetter(correct)) return null;

  const analysis: Partial<Record<Letter, string>> = {};
  const ra = r.analysis ?? r.alternativesAnalysis ?? r.analise;
  if (Array.isArray(ra)) {
    ra.slice(0, 5).forEach((a, i) => {
      const t = str(a);
      if (t) analysis[LETTERS[i]] = t;
    });
  } else if (ra && typeof ra === "object") {
    const obj = ra as Record<string, unknown>;
    for (const L of LETTERS) {
      const t = str(obj[L] ?? obj[L.toLowerCase()]);
      if (t) analysis[L] = t;
    }
  }

  const summary = str(r.summary ?? r.explanation ?? r.comentario) || analysis[correct] || "";
  if (!summary) return null;

  return {
    topic: clip(fallbackTopic || str(r.topic), 140),
    supportText: str(r.supportText) || null,
    statement,
    options: options as Options,
    correct,
    summary,
    legalBasis: str(r.legalBasis ?? r.fundamentacao) || null,
    lawText: str(r.lawText ?? r.letraDaLei) || null,
    analysis,
    tip: str(r.tip ?? r.dica) || null,
    difficulty: str(r.difficulty) || null,
  };
}

function toRow(quizId: string, item: PlanItem, q: GeneratedQuestion, origin: string, engine: string, bankId?: string): NewQuestion {
  return {
    quizId,
    position: item.position,
    topic: item.topic || q.topic,
    supportText: q.supportText,
    statement: q.statement,
    options: q.options,
    correct: q.correct,
    summary: q.summary,
    legalBasis: q.legalBasis,
    lawText: q.lawText,
    lawUrl: lawUrlFor(q.legalBasis),
    analysis: q.analysis,
    tip: q.tip,
    difficulty: q.difficulty,
    origin,
    engine,
    bankId: bankId ?? null,
  };
}

async function bankUsage(): Promise<Map<string, number>> {
  const rows = await db
    .select({ bankId: questions.bankId, n: sql<number>`count(*)::int` })
    .from(questions)
    .where(isNotNull(questions.bankId))
    .groupBy(questions.bankId);
  return new Map(rows.map((r) => [String(r.bankId), Number(r.n)]));
}

/**
 * Seleciona questões do banco curado SOMENTE quando o tópico da questão corresponde
 * estritamente ao tópico planejado (`item.topic`) e ao tema central (`quizSubject`).
 * Jamais mistura questões de outros tópicos da matéria.
 */
function pickBankStrict(
  pool: BankQuestion[],
  items: PlanItem[],
  quizSubject: string,
  usage: Map<string, number>,
  exclude: Set<string>,
  onlyUnused: boolean,
): Array<{ item: PlanItem; bank: BankQuestion }> {
  const available = shuffle(pool.filter((b) => !exclude.has(b.id) && (!onlyUnused || !usage.get(b.id))));
  const picks: Array<{ item: PlanItem; bank: BankQuestion }> = [];
  for (const item of items) {
    const candidates = available
      .filter((b) => !exclude.has(b.id) && isStrictBankMatch(b, item.topic, quizSubject))
      .sort(
        (a, b) =>
          similarity(item.topic, b.topic) - similarity(item.topic, a.topic) ||
          (usage.get(a.id) ?? 0) - (usage.get(b.id) ?? 0),
      );
    const bank = candidates[0];
    if (!bank) continue;
    picks.push({ item, bank });
    exclude.add(bank.id);
  }
  return picks;
}

/**
 * Reúne trechos de lei e conceitos-chave conferidos especificamente sobre o tema pedido,
 * ancorando a IA na redação oficial para evitar desvios de foco ou alucinações.
 */
function pickReferences(
  quizSubject: string,
  pool: BankQuestion[],
  items: PlanItem[],
  max: number,
): LegalReferenceNote[] {
  const seen = new Set<string>();
  const out: LegalReferenceNote[] = [];
  const push = (note: LegalReferenceNote) => {
    if (!note.legalBasis || !note.lawText) return;
    if (seen.has(note.legalBasis)) return;
    seen.add(note.legalBasis);
    out.push(note);
  };

  // 1) Notas oficiais do motor de foco para o tema central e para cada recorte do plano.
  for (const n of resolveFocus(quizSubject).references) push(n);
  for (const it of items) {
    for (const n of resolveFocus(it.topic).references) push(n);
  }

  // 2) Dispositivos e conceitos das questões do banco que guardam pertinência com os itens pedidos.
  const withText = pool.filter((b) => b.lawText && b.legalBasis);
  const scored = withText
    .map((b) => ({
      b,
      s: Math.max(...items.map((i) => similarity(`${quizSubject} ${i.topic}`, `${b.topic} ${b.legalBasis}`))),
    }))
    .filter((x) => x.s > 0.12)
    .sort((a, b) => b.s - a.s);

  for (const { b } of scored) {
    if (out.length >= max) break;
    push({ legalBasis: b.legalBasis as string, lawText: b.lawText as string });
  }
  return out.slice(0, max);
}

async function generateWithAi(
  quiz: QuizRow,
  items: PlanItem[],
  avoid: string[],
  provider: ProviderInfo,
  pool: BankQuestion[],
): Promise<{ out: Array<{ item: PlanItem; q: GeneratedQuestion }>; engine: string }> {
  const references = pickReferences(quiz.subject, pool, items, provider.premium ? 8 : 5);
  const matchingExamples = pool.filter((b) => items.some((it) => isStrictBankMatch(b, it.topic, quiz.subject)));
  const example = matchingExamples.length ? matchingExamples[Math.floor(Math.random() * matchingExamples.length)] : undefined;

  const { data, model } = await chatJSON<Record<string, unknown>>(
    {
      system: GENERATION_SYSTEM,
      user: generationPrompt({ subject: quiz.subject, cargo: quiz.cargo, plan: items, references, avoid, example }),
      temperature: 0.7,
      maxTokens: provider.premium ? 2600 * items.length + 3000 : 6000,
      timeoutMs: provider.premium ? 110_000 : 150_000,
    },
    provider,
  );
  let list: unknown[] = [];
  if (Array.isArray(data.questions)) list = data.questions;
  else if (typeof data.statement === "string") list = [data];
  else list = (Object.values(data).find((v) => Array.isArray(v)) as unknown[] | undefined) ?? [];

  const out: Array<{ item: PlanItem; q: GeneratedQuestion }> = [];
  list.slice(0, items.length).forEach((raw, i) => {
    const q = normalizeQuestion(raw, items[i].topic);
    if (q) out.push({ item: items[i], q });
  });
  return { out, engine: `${provider.label} · ${model}` };
}

export interface GenerateResult {
  generated: number[];
  missing: number[];
  total: number;
  status: string;
  warning?: string;
}

export async function generateForPositions(quizId: string, positions: number[]): Promise<GenerateResult> {
  const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, quizId)).limit(1);
  if (!quiz) throw new HttpError(404, "Simulado não encontrado.");

  const existing = await db
    .select({ position: questions.position, statement: questions.statement, bankId: questions.bankId })
    .from(questions)
    .where(eq(questions.quizId, quizId));
  const have = new Set(existing.map((e) => e.position));
  const items = quiz.plan.filter((p) => positions.includes(p.position) && !have.has(p.position)).slice(0, 5);
  let warning: string | undefined;

  if (items.length && quiz.status === "generating") {
    const provider = getProvider();
    const focus = resolveFocus(quiz.subject);
    const def = focus.subjectDef ?? matchSubject(quiz.subject);
    const pool = def ? bankFor(def.bank) : [];
    const exclude = new Set(existing.map((e) => e.bankId).filter((x): x is string => Boolean(x)));
    const rows: NewQuestion[] = [];
    let remaining = items;
    const take = (done: PlanItem[]) => {
      const ids = new Set(done.map((d) => d.position));
      remaining = remaining.filter((i) => !ids.has(i.position));
    };

    // 1) Sem IA premium: prioriza APENAS questões inéditas do banco que batam estritamente com o tema pedido.
    if (!provider.premium && pool.length) {
      const picks = pickBankStrict(pool, remaining, quiz.subject, await bankUsage(), exclude, true);
      for (const p of picks) rows.push(toRow(quizId, p.item, p.bank, "banco", "Banco curado", p.bank.id));
      take(picks.map((p) => p.item));
    }

    // 2) IA (premium ou gratuita) ancorada nas referências oficiais e travada em 100% no tema.
    if (remaining.length && (provider.premium || freeAiEnabled())) {
      try {
        const avoid = existing.map((e) => clip(e.statement, 160));
        const { out, engine } = await generateWithAi(quiz, remaining, avoid, provider, pool);
        for (const o of out) rows.push(toRow(quizId, o.item, o.q, provider.premium ? "ia" : "ia-gratuita", engine));
        take(out.map((o) => o.item));
        if (!out.length) warning = "A IA retornou questões em formato inválido.";
      } catch (err) {
        warning = `IA indisponível no momento (${clip(String((err as Error)?.message ?? err), 120)}).`;
      }
    }

    // 3) Contingência: banco curado, mas ainda mantendo correspondência estrita ao tema pedido.
    if (remaining.length && pool.length) {
      const picks = pickBankStrict(pool, remaining, quiz.subject, await bankUsage(), exclude, false);
      for (const p of picks) rows.push(toRow(quizId, p.item, p.bank, "banco", "Banco curado", p.bank.id));
      take(picks.map((p) => p.item));
    }

    if (rows.length) {
      await db.insert(questions).values(rows).onConflictDoNothing({ target: [questions.quizId, questions.position] });
    } else if (warning) {
      throw new HttpError(
        502,
        `${warning}${pool.length ? "" : " Para este tema, configure uma chave de IA (ex.: OPENAI_API_KEY ou GEMINI_API_KEY) para gerar questões com máxima confiabilidade."}`,
      );
    }
  }

  const after = await db.select({ position: questions.position }).from(questions).where(eq(questions.quizId, quizId));
  const done = new Set(after.map((a) => a.position));
  let status = quiz.status;
  if (status === "generating" && done.size >= quiz.questionCount) {
    status = "ready";
    await db.update(quizzes).set({ status }).where(and(eq(quizzes.id, quizId), eq(quizzes.status, "generating")));
  }
  return {
    generated: positions.filter((p) => done.has(p)),
    missing: positions.filter((p) => !done.has(p)),
    total: done.size,
    status,
    warning,
  };
}

/** Encerra a geração mantendo apenas as questões já elaboradas. */
export async function finalizeGeneration(quizId: string): Promise<void> {
  const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, quizId)).limit(1);
  if (!quiz) throw new HttpError(404, "Simulado não encontrado.");
  if (quiz.status !== "generating") return;
  const after = await db.select({ position: questions.position }).from(questions).where(eq(questions.quizId, quizId));
  if (!after.length) throw new HttpError(400, "Nenhuma questão foi gerada ainda.");
  const done = new Set(after.map((a) => a.position));
  await db
    .update(quizzes)
    .set({ questionCount: after.length, status: "ready", plan: quiz.plan.filter((p) => done.has(p.position)) })
    .where(eq(quizzes.id, quizId));
}
