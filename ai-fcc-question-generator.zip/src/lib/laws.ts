const P = "https://www.planalto.gov.br/ccivil_03";

/** Mapa de diplomas legais -> texto oficial compilado (Planalto). Ordem importa. */
const MAP: { re: RegExp; url: string }[] = [
  { re: /(^|\D)8\.?112(\D|$)/, url: `${P}/leis/l8112cons.htm` },
  { re: /(^|\D)9\.?784(\D|$)/, url: `${P}/leis/l9784.htm` },
  { re: /(^|\D)8\.?429(\D|$)|improbidade/i, url: `${P}/leis/l8429.htm` },
  { re: /(^|\D)14\.?133(\D|$)/, url: `${P}/_ato2019-2022/2021/lei/l14133.htm` },
  { re: /(^|\D)12\.?527(\D|$)|acesso à informação/i, url: `${P}/_ato2011-2014/2011/lei/l12527.htm` },
  { re: /(^|\D)13\.?146(\D|$)|pessoa com deficiência/i, url: `${P}/_ato2015-2018/2015/lei/l13146.htm` },
  { re: /(^|\D)1\.?171(\D|$)/, url: `${P}/decreto/d1171.htm` },
  { re: /(^|\D)12\.?813(\D|$)/, url: `${P}/_ato2011-2014/2013/lei/l12813.htm` },
  { re: /(^|\D)13\.?709(\D|$)|lgpd/i, url: `${P}/_ato2015-2018/2018/lei/l13709.htm` },
  { re: /(^|\D)13\.?303(\D|$)/, url: `${P}/_ato2015-2018/2016/lei/l13303.htm` },
  { re: /decreto-lei n?º? ?200|dl ?200/i, url: `${P}/decreto-lei/del0200.htm` },
  { re: /(^|\D)5\.?172(\D|$)|\bctn\b|tributário nacional/i, url: `${P}/leis/l5172compilado.htm` },
  { re: /(^|\D)2\.?848(\D|$)|código penal/i, url: `${P}/decreto-lei/del2848compilado.htm` },
  { re: /(^|\D)3\.?689(\D|$)|processo penal/i, url: `${P}/decreto-lei/del3689compilado.htm` },
  { re: /(^|\D)13\.?105(\D|$)|processo civil/i, url: `${P}/_ato2015-2018/2015/lei/l13105.htm` },
  { re: /(^|\D)10\.?406(\D|$)|código civil/i, url: `${P}/leis/2002/l10406compilada.htm` },
  { re: /(^|\D)5\.?452(\D|$)|\bclt\b/i, url: `${P}/decreto-lei/del5452.htm` },
  { re: /(^|\D)8\.?069(\D|$)|\beca\b/i, url: `${P}/leis/l8069.htm` },
  { re: /(^|\D)10\.?741(\D|$)|estatuto d[ao] (pessoa )?idos/i, url: `${P}/leis/2003/l10.741.htm` },
  { re: /(^|\D)11\.?340(\D|$)|maria da penha/i, url: `${P}/_ato2004-2006/2006/lei/l11340.htm` },
  { re: /(^|\D)8\.?213(\D|$)/, url: `${P}/leis/l8213cons.htm` },
  { re: /(^|\D)8\.?078(\D|$)|defesa do consumidor/i, url: `${P}/leis/l8078compilado.htm` },
  { re: /(^|\D)8\.?080(\D|$)/, url: `${P}/leis/l8080.htm` },
  { re: /(^|\D)9\.?394(\D|$)|diretrizes e bases/i, url: `${P}/leis/l9394.htm` },
  { re: /101\/2000|responsabilidade fiscal/i, url: `${P}/leis/lcp/lcp101.htm` },
  { re: /(^|\D)4\.?320(\D|$)/, url: `${P}/leis/l4320.htm` },
  { re: /(^|\D)12\.?846(\D|$)|anticorrupção/i, url: `${P}/_ato2011-2014/2013/lei/l12846.htm` },
  { re: /constitui[çc][ãa]o|\bcf\b|cf\/88|crfb/i, url: `${P}/constituicao/constituicao.htm` },
];

const LEGAL_HINT = /\b(lei|decreto|constitui|cf\b|cf\/|art\.|artigo|c[óo]digo|s[úu]mula|emenda|estatuto|regimento|resolu[çc][ãa]o|lc\b)/i;

export function isLegalReference(basis: string | null | undefined): boolean {
  if (!basis) return false;
  return LEGAL_HINT.test(basis) && !/^(norma-padr[ãa]o|conceito|regra)/i.test(basis.trim());
}

export function lawUrlFor(basis: string | null | undefined): string | null {
  if (!basis || !isLegalReference(basis)) return null;
  for (const m of MAP) if (m.re.test(basis)) return m.url;
  return `https://www.google.com/search?q=${encodeURIComponent(`${basis} site:planalto.gov.br`)}`;
}
