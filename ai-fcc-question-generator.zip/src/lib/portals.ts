export interface Portal {
  domain: string;
  name: string;
}

/** Grandes e conceituados portais de concursos do Brasil (whitelist de fontes). */
export const PORTALS: Portal[] = [
  { domain: "estrategiaconcursos.com.br", name: "Estratégia Concursos" },
  { domain: "estrategia.com", name: "Estratégia" },
  { domain: "tecconcursos.com.br", name: "TEC Concursos" },
  { domain: "qconcursos.com", name: "QConcursos" },
  { domain: "grancursosonline.com.br", name: "Gran Cursos Online" },
  { domain: "direcaoconcursos.com.br", name: "Direção Concursos" },
  { domain: "pciconcursos.com.br", name: "PCI Concursos" },
  { domain: "alfaconcursos.com.br", name: "AlfaCon" },
  { domain: "folhadirigida.com.br", name: "Folha Dirigida" },
  { domain: "jcconcursos.com.br", name: "JC Concursos" },
  { domain: "concursosnobrasil.com", name: "Concursos no Brasil" },
  { domain: "aprovaconcursos.com.br", name: "Aprova Concursos" },
  { domain: "casadoconcurseiro.com.br", name: "Casa do Concurseiro" },
  { domain: "novaconcursos.com.br", name: "Nova Concursos" },
  { domain: "questoesestrategicas.com.br", name: "Questões Estratégicas" },
  { domain: "focusconcursos.com.br", name: "Focus Concursos" },
  { domain: "acheconcursos.com.br", name: "Ache Concursos" },
  { domain: "estudegratis.com.br", name: "Estude Grátis" },
  { domain: "concursosfcc.com.br", name: "FCC (site oficial)" },
];

/** Principais domínios para buscadores que aceitam filtro de domínio. */
export const TOP_PORTAL_DOMAINS = [
  "estrategiaconcursos.com.br",
  "tecconcursos.com.br",
  "qconcursos.com",
  "grancursosonline.com.br",
  "direcaoconcursos.com.br",
  "pciconcursos.com.br",
  "alfaconcursos.com.br",
  "folhadirigida.com.br",
  "jcconcursos.com.br",
  "concursosfcc.com.br",
];

export function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return "";
  }
}

export function portalFor(url: string): Portal | null {
  const host = hostOf(url);
  if (!host) return null;
  return PORTALS.find((p) => host === p.domain || host.endsWith(`.${p.domain}`)) ?? null;
}
