import { FCC_INTERNAL_ANGLES } from "./focus";
import { clip } from "./text";
import type { BankQuestion, Letter, ResearchSource } from "./types";

export const RESEARCH_SYSTEM =
  "Você é um analista sênior de concursos públicos brasileiros e conhece profundamente o perfil da Fundação Carlos Chagas (FCC). " +
  "Sua função é identificar, com base em fontes dos principais portais de concursos (Estratégia Concursos, TEC Concursos, QConcursos, " +
  "Gran Cursos Online, Direção Concursos, PCI Concursos, entre outros), os pontos mais cobrados pela FCC em provas de NÍVEL MÉDIO " +
  "(Técnico, Assistente, Auxiliar), mantendo FOCO 100% ESTRITO no tema exato informado pelo usuário. Responda SOMENTE com JSON válido, sem markdown.";

export function researchPrompt(
  subject: string,
  cargo: string | null,
  sources: ResearchSource[],
  extracts: Record<number, string>,
  extractLimit = 1800,
  isSpecificTheme = false,
): string {
  const src = sources.length
    ? sources
        .map(
          (s) =>
            `[${s.id}] (${s.portal}) ${s.title}\nURL: ${s.url}\nTrecho: ${s.snippet || "—"}` +
            (extracts[s.id] ? `\nConteúdo relevante da página:\n${clip(extracts[s.id], extractLimit)}` : ""),
        )
        .join("\n\n")
    : 'Nenhuma fonte pôde ser coletada ao vivo. Baseie-se no seu conhecimento consolidado dos levantamentos estatísticos publicados pelos portais de concursos sobre a FCC e deixe "sources" vazio.';

  const focusRule = isSpecificTheme
    ? `REGRA INEGOCIÁVEL DE FOCO 100% NO TEMA ESPECÍFICO:
O usuário informou um TEMA ESPECÍFICO ("${subject}").
- 100% dos itens em "topics" DEVEM ser subtópicos, dispositivos, regras ou pegadinhas INTERNAS a "${subject}".
- É TERMINANTEMENTE PROIBIDO incluir outros assuntos da disciplina geral que fujam de "${subject}" (por exemplo: se o tema é "Crase", liste APENAS recortes de Crase; se é "Atos Administrativos", liste APENAS recortes de Atos Administrativos).`
    : `REGRA DE FOCO 100%:
Todos os itens em "topics" devem pertencer estritamente a "${subject}", priorizando os pontos de maior incidência histórica nas provas de nível médio da FCC.`;

  return `TEMA / ASSUNTO CENTRAL DO USUÁRIO (FOCO 100%): ${subject}
CARGO/ÓRGÃO: ${cargo || "não informado (considere cargos de nível médio em geral: Técnico Judiciário, Técnico Administrativo, Assistente etc.)"}

${focusRule}

FONTES COLETADAS NOS PORTAIS DE CONCURSOS:
${src}

TAREFA:
1. Liste de 6 a 8 recortes/subtópicos mais cobrados pela FCC DENTRO de "${subject}" em provas de nível médio, do mais para o menos cobrado.
2. Cada item em "topics" deve manter foco 100% em "${subject}" e ser específico para orientar a geração de questões.
3. "relevance": inteiro de 0 a 100 estimando a incidência relativa na FCC.
4. "why": uma frase curta explicando exatamente como a FCC cobra esse ponto de "${subject}".
5. "sources": números das fontes que embasam o item ([] se vier do seu conhecimento do histórico da banca). Nunca cite fontes inexistentes.
6. "summary": 2 ou 3 frases analisando exclusivamente como a FCC cobra "${subject}".
7. "styleTips": de 3 a 5 dicas curtas e práticas focadas 100% em como acertar questões da FCC sobre "${subject}".

FORMATO EXATO:
{"topics":[{"name":"...","relevance":95,"why":"...","sources":[1]}],"summary":"...","styleTips":["..."]}`;
}

export const GENERATION_SYSTEM =
  "Você é um elaborador sênior de questões da Fundação Carlos Chagas (FCC) e professor especialista em concursos públicos, " +
  "com domínio da legislação brasileira atualizada. Elabore questões INÉDITAS, tecnicamente impecáveis, no estilo FCC, para cargos " +
  "de NÍVEL MÉDIO, com FOCO 100% ABSOLUTO E EXCLUSIVO no tema solicitado pelo usuário e comentários criteriosos. " +
  "Responda SOMENTE com JSON válido (sem markdown e sem texto fora do JSON).";

export function generationPrompt(args: {
  subject: string;
  cargo: string | null;
  plan: { position?: number; topic: string; letter: Letter }[];
  references: { legalBasis: string; lawText: string }[];
  avoid: string[];
  example?: BankQuestion;
}): string {
  const { subject, cargo, plan, references, avoid, example } = args;
  const planText = plan
    .map((p, i) => {
      const idx = (p.position ?? i + 1) - 1;
      const angle = FCC_INTERNAL_ANGLES[idx % FCC_INTERNAL_ANGLES.length];
      return `${i + 1}. Tema obrigatório (100% foco): "${p.topic}" (dentro de "${subject}") — ângulo sugerido: ${angle} — gabarito obrigatório: ${p.letter}`;
    })
    .join("\n");

  const refs = references.length
    ? references.map((r) => `- ${r.legalBasis}:\n"${clip(r.lawText, 950)}"`).join("\n")
    : "- (sem trechos pré-carregados; utilize exclusivamente dispositivos e regras oficiais vigentes que você domina com exatidão sobre o tema)";
  const avoidText = avoid.length ? avoid.map((a) => `- ${a}`).join("\n") : "- (nenhuma)";
  const exampleJson = example
    ? JSON.stringify({
        topic: example.topic,
        supportText: example.supportText ?? "",
        statement: example.statement,
        options: example.options,
        correct: example.correct,
        summary: example.summary,
        legalBasis: example.legalBasis,
        lawText: example.lawText,
        analysis: example.analysis,
        tip: example.tip,
        difficulty: example.difficulty,
      })
    : "";

  return `TEMA CENTRAL OBRIGATÓRIO DO USUÁRIO (FOCO 100%): ${subject}
CARGO/ÓRGÃO: ${cargo || "nível médio (Técnico/Assistente)"}
QUANTIDADE: ${plan.length} questão(ões)

TRAVA INEGOCIÁVEL DE FOCO 100% NO TEMA:
- O usuário exigiu FOCO MÁXIMO (100%) em "${subject}".
- É TERMINANTEMENTE PROIBIDO elaborar questão sobre qualquer assunto fora de "${subject}" e do recorte especificado no plano.
- O enunciado, todas as 5 alternativas (A a E), a fundamentação legal, a letra da lei e o comentário resumido DEVEM tratar 100% de "${subject}".
- Quando houver mais de uma questão sobre o mesmo tema, explore dispositivos, incisos, parágrafos, casos práticos ou pegadinhas diferentes DENTRO de "${subject}", sem jamais sair do tema.

PLANO (siga exatamente, na ordem — tema, ângulo e letra do gabarito de cada questão):
${planText}

CARACTERÍSTICAS OBRIGATÓRIAS DO ESTILO FCC:
- Cinco alternativas (A a E) e apenas UMA correta. Distratores plausíveis que explorem pegadinhas típicas da FCC dentro do tema: troca de prazos, números, competências, exceções e palavras como "sempre", "apenas", "vedado", "facultado".
- Forte apego à literalidade da lei ("letra da lei") nas matérias jurídicas.
- Varie os formatos de enunciado: (a) comando direto ("De acordo com a Lei nº ..., ..."); (b) situação hipotética com personagens (ex.: "Mário, servidor público..."); (c) itens I, II e III com o comando "Está correto o que se afirma em" e alternativas como "I, apenas.", "I e II, apenas.", "I, II e III."; (d) lacunas "....." com o comando "Preenchem, correta e respectivamente, as lacunas:"; (e) "É correto afirmar que".
- Linguagem formal, norma-padrão, enunciados claros e nível médio (sem aprofundamento doutrinário excessivo).
- Use "\\n" para separar os itens I, II e III no enunciado.
- Em Língua Portuguesa, quando o recorte exigir, inclua um texto-base curto e original em "supportText" (até 120 palavras) e formule a questão sobre ele. Nas demais matérias, deixe "supportText" vazio.
- As alternativas NÃO devem começar com a letra (escreva só o texto).

COMENTÁRIO CRITERIOSO FOCADO 100% NO ASSUNTO (obrigatório em cada questão):
- "summary": explicação resumida, didática e 100% focada em "${subject}" (3 a 6 frases), justificando criteriosamente o gabarito.
- "legalBasis": dispositivo exato pertinente ao tema (ex.: "Lei nº 8.112/1990, art. 29, I" ou "CF/1988, art. 5º, LXXII"). Se a matéria não for jurídica, informe a regra ou o conceito de referência começando por "Norma-padrão:" ou "Conceito-chave:".
- "lawText": transcrição LITERAL e fiel do dispositivo (a letra da lei). Se não tiver certeza absoluta da redação oficial, deixe "" — NUNCA invente texto de lei. Nas matérias não jurídicas, enuncie a regra ou o conceito-chave do tema.
- "analysis": objeto com a análise de TODAS as alternativas (A a E), cada uma começando por "Correta." ou "Errada." e explicando o motivo com foco no tema.
- "tip": dica ou pegadinha típica da FCC especificamente sobre esse ponto de "${subject}" (1 a 2 frases).
- "difficulty": "Fácil", "Média" ou "Difícil".

TRECHOS DE REFERÊNCIA DO TEMA (redação oficial conferida — use-os quando pertinentes):
${refs}

QUESTÕES JÁ ELABORADAS NESTE SIMULADO (não repita nem parafraseie):
${avoidText}
${exampleJson ? `\nEXEMPLO DE QUESTÃO NO PADRÃO ESPERADO (apenas referência de formato; não copie):\n${exampleJson}\n` : ""}
FORMATO DE SAÍDA (JSON puro):
{"questions":[{"topic":"...","supportText":"","statement":"...","options":{"A":"...","B":"...","C":"...","D":"...","E":"..."},"correct":"C","summary":"...","legalBasis":"...","lawText":"...","analysis":{"A":"Errada. ...","B":"Errada. ...","C":"Correta. ...","D":"Errada. ...","E":"Errada. ..."},"tip":"...","difficulty":"Média"}]}`;
}
